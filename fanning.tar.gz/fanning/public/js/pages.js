// Sahifalar: dashboard, dasturlar ro'yxati, dastur tafsilotlari
'use strict';

// ---------- Dashboard ----------
route(/^\/$/, async () => {
  const d = await GET('/api/dashboard'); const s = d.stats; const u = state.user;
  const cards = [
    ['Jami dasturlar', s.total, '', ''], ['Qoralamalar', s.draft, 'draft', ''], ['Tekshiruvda', s.review, 'review', ''],
    ['Tasdiqlashga tayyor', s.ready, 'ready', ''], ['Qaytarilgan', s.returned, 'returned', ''], ['Muddati o\'tgan', s.overdue, 'overdue', s.overdue ? 'warn' : ''], ['Tasdiqlangan', s.approved, 'approved', 'good'],
  ];
  const link = (k) => k === '' ? '#/programs' : (k === 'draft' || k === 'ready') ? `#/programs?status=${k}` : `#/programs?group=${k}`;
  const hello = { teacher: "Dasturlaringiz holatini kuzating va izohlar bo'yicha tuzatishlarni kiriting.", methodist: "Sizga biriktirilgan dasturlarni tekshiring va izoh qoldiring.", head: "Metodik tekshiruvdan o'tgan dasturlarni ko'rib chiqing va yakuniy qaror bering.", admin: "Tizim foydalanuvchilari, ma'lumotnomalar va sozlamalarni boshqaring." }[u.role];
  return `<div class="page-head"><div><h1>Assalomu alaykum, ${esc(u.full_name.split(' ')[0])}!</h1><p>${hello}</p></div>${u.role === 'teacher' ? `<a class="btn primary right" href="#/new">${ic('plus')} Yangi dastur</a>` : ''}</div>
  <div class="grid g7">${cards.map(([l, n, k, c]) => `<a class="stat ${c}" href="${link(k)}"><div class="n">${n}</div><div class="l">${l}</div></a>`).join('')}</div>
  <div class="split" style="margin-top:20px"><div class="card"><h2>${{ teacher: "Sizning vazifalaringiz", methodist: 'Tekshiruv navbati', head: 'Tasdiqlash navbati', admin: 'So\'nggi dasturlar' }[u.role]}</h2>
  ${d.todo.length ? `<div class="tbl-wrap" style="box-shadow:none"><table class="tbl"><thead><tr><th>Fan</th><th>Holat</th><th>Muddat</th></tr></thead><tbody>${d.todo.map(r => `<tr class="link" data-href="#/program/${r.id}"><td><b>${esc(r.subject)}</b><div class="muted small">${esc(r.year)} · ${esc(r.author)}</div></td><td>${badge(r.status)}</td><td class="nowrap">${r.review_due && ['submitted', 'in_review', 'resubmitted'].includes(r.status) ? `<span class="${r.overdue ? 'badge over' : 'muted'}">${daysLeft(r.review_due)}</span>` : r.approval_due && r.status === 'ready' ? `<span class="${r.overdue ? 'badge over' : 'muted'}">${daysLeft(r.approval_due)}</span>` : '<span class="muted">—</span>'}</td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">Hozircha bajariladigan vazifa yo'q 🎉</div>`}</div>
  <div class="card"><h2>So'nggi harakatlar</h2>${d.activity.length ? `<ul class="tl">${d.activity.map(a => `<li><a href="#/program/${a.curriculum_id}"><b>${esc(a.title)}</b></a><div>${badge(a.to_status)}</div><div class="muted small">${esc(a.actor || 'Tizim')} · ${fmtDT(a.at)}</div></li>`).join('')}</ul>` : '<div class="empty">Harakat yo\'q</div>'}</div></div>`;
});

// ---------- Dasturlar ro'yxati ----------
const LIST_TITLES = { teacher: ['Mening dasturlarim', "Siz yaratgan o'quv dasturlari"], methodist: ['Tekshiruv uchun dasturlar', 'Sizga biriktirilgan dasturlar'], head: ['Tasdiqlash uchun dasturlar', "Metodik tekshiruvdan o'tgan va qaror kutayotgan dasturlar"], admin: ['Barcha dasturlar', "Tizimdagi barcha o'quv dasturlari (faqat ko'rish)"] };
function programRows(rows) {
  if (!rows.length) return `<tr><td colspan="6"><div class="empty">Dastur topilmadi</div></td></tr>`;
  return rows.map(r => `<tr class="link" data-href="#/program/${r.id}"><td class="muted">№${r.id}</td><td><b>${esc(r.subject)}</b><div class="muted small">${esc(r.subject_code)} · ${esc(r.direction || '')}</div></td><td>${esc(r.year)}</td><td>${esc(r.author)}${r.reviewer ? `<div class="muted small">Metodist: ${esc(r.reviewer)}</div>` : ''}</td><td>${badge(r.status)} ${r.overdue ? '<span class="badge over">Muddati o\'tgan</span>' : ''}</td><td class="nowrap muted">v${r.current_version} · ${fmtDate(r.updated_at)}</td></tr>`).join('');
}
function yearOptions(sel) { return `<option value="">Barcha o'quv yillari</option>${state.meta.years.map(y => `<option value="${y.id}" ${String(sel) === String(y.id) ? 'selected' : ''}>${esc(y.name)}</option>`).join('')}`; }
function subjectOptions(sel) { return `<option value="">Barcha fanlar</option>${state.meta.subjects.map(y => `<option value="${y.id}" ${String(sel) === String(y.id) ? 'selected' : ''}>${esc(y.name)}</option>`).join('')}`; }

route(/^\/programs$/, async (m, p) => {
  const [t, sub] = LIST_TITLES[state.user.role];
  const rows = await GET('/api/programs?' + qs(p));
  const groups = { '': 'Barchasi', review: 'Tekshiruvda', returned: 'Qaytarilgan', overdue: "Muddati o'tgan", approved: 'Tasdiqlangan' };
  return `<div class="page-head"><div><h1>${t}</h1><p>${sub}</p></div>${state.user.role === 'teacher' ? `<a class="btn primary right" href="#/new">${ic('plus')} Yangi dastur</a>` : ''}</div>
  <form class="filters" id="flt"><input type="text" name="q" placeholder="Qidirish: fan, kod, muallif…" value="${esc(p.q || '')}"><select name="status"><option value="">Barcha holatlar</option>${Object.entries(state.meta.status).map(([k, v]) => `<option value="${k}" ${p.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
  <select name="group">${Object.entries(groups).map(([k, v]) => `<option value="${k}" ${(p.group || '') === k ? 'selected' : ''}>${v}</option>`).join('')}</select><select name="year">${yearOptions(p.year)}</select><select name="subject">${subjectOptions(p.subject)}</select></form>
  <div class="tbl-wrap"><table class="tbl"><thead><tr><th>№</th><th>Fan</th><th>O'quv yili</th><th>Muallif</th><th>Holat</th><th>Yangilangan</th></tr></thead><tbody id="tb">${programRows(rows)}</tbody></table></div>`;
}, { after: (m, p) => {
  const f = $('#flt'); let t;
  const go = () => { const o = Object.fromEntries(new FormData(f)); location.hash = '#/programs?' + qs(o); };
  f.querySelectorAll('select').forEach(s => s.onchange = go);
  f.q.oninput = () => { clearTimeout(t); t = setTimeout(go, 400); };
  if (p.q) { f.q.focus(); f.q.setSelectionRange(99, 99); }
} });

// ---------- Yangi dastur ----------
route(/^\/new$/, async () => {
  const M = state.meta;
  return `<div class="crumbs"><a href="#/programs">Mening dasturlarim</a> / Yangi dastur</div><div class="page-head"><h1>Yangi o'quv dasturi</h1></div>
  <div class="card" style="max-width:640px"><form id="nf"><div class="field"><label class="f">Fan</label><select name="subject_id" required><option value="">Tanlang…</option>${M.subjects.map(s => `<option value="${s.id}">${esc(s.name)} (${esc(s.code)})</option>`).join('')}</select></div>
  <div class="field"><label class="f">O'quv yili</label><select name="year_id" required>${M.years.map(y => `<option value="${y.id}">${esc(y.name)}</option>`).join('')}</select></div>
  <div class="field"><label class="f">Shablon</label><select name="template_id">${M.templates.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select><div class="hint">Shablon majburiy maydonlarni belgilaydi. Dastur qoralama sifatida yaratiladi, keyin to'ldirasiz.</div></div>
  <button class="btn primary">Yaratish va to'ldirishni boshlash</button></form></div>`;
}, { roles: ['teacher'], after: () => {
  $('#nf').onsubmit = async (e) => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); try { const r = await POST('/api/programs', { subject_id: +f.subject_id, year_id: +f.year_id, template_id: +f.template_id || null }); location.hash = `#/program/${r.id}/edit`; } catch (err) { fail(err); } };
} });

// ---------- Dastur tafsilotlari ----------
const SEC_ORDER = ['goals', 'objectives', 'outcomes', 'topics', 'literature'];
let cur = null; // joriy ochilgan dastur

function flowHtml(d) {
  const steps = [['draft', 'Qoralama'], ['submitted', 'Yuborilgan'], ['in_review', 'Metodik tekshiruv'], ['ready', 'Tasdiqlashga tayyor'], ['approved', 'Tasdiqlangan'], ['archived', 'Arxivlangan']];
  const idx = { draft: 0, submitted: 1, resubmitted: 1, in_review: 2, revision: 2, ready: 3, rejected: 3, approved: 4, archived: 5 }[d.status];
  return `<div class="flow">${steps.map(([k, l], i) => {
    const now = i === idx; const done = i < idx || (d.status === 'archived');
    let label = l, cls = done && !now ? 'done' : now ? 'now' : '';
    if (now && d.status === 'revision') { cls += ' warn'; label = 'Tuzatish talab qilinadi'; }
    if (now && d.status === 'rejected') { cls += ' bad'; label = 'Rad etildi'; }
    if (now && d.status === 'resubmitted') label = 'Qayta yuborilgan';
    if (d.status === 'archived' && i === 5) cls = 'done now';
    return `<div class="st ${cls}"><div class="c">${done && !now ? '✓' : i + 1}</div><div class="t">${label}</div></div>`;
  }).join('')}</div>`;
}

function contentTab(d) {
  const c = d.content; const reviewing = state.user.role === 'methodist' && d.status === 'in_review' && d.version.is_latest;
  const openBy = {}; d.comments.filter(x => x.status === 'open').forEach(x => { openBy[x.section] = (openBy[x.section] || 0) + 1; });
  const blk = (key, title, body) => `<div class="sec-block ${openBy[key] ? 'flagged' : ''}"><div class="hd"><h3>${title}</h3>${openBy[key] ? `<span class="badge revision">${openBy[key]} ta ochiq izoh</span>` : ''}${reviewing ? `<button class="btn sm right" data-act="addcomment" data-section="${key}">+ Izoh</button>` : ''}</div>${body}</div>`;
  const txt = (s) => `<div class="body">${s ? esc(s) : '<span class="muted">Kiritilmagan</span>'}</div>`;
  const total = c.topics.reduce((a, t) => a + t.hours, 0);
  return `<div class="sec-block"><div class="hd"><h3>Asosiy parametrlar</h3></div><div class="grid g4"><div><div class="muted small">Kurs</div><b>${esc(c.course) || '—'}</b></div><div><div class="muted small">Semestr</div><b>${esc(c.semester) || '—'}</b></div><div><div class="muted small">Umumiy soat</div><b>${c.total_hours || '—'}</b></div><div><div class="muted small">Mavzular soati</div><b class="${total === c.total_hours ? '' : 'muted'}">${total}</b></div></div></div>
  ${blk('goals', 'Maqsad', txt(c.goals))}${blk('objectives', 'Vazifalar', txt(c.objectives))}${blk('outcomes', "O'quv natijalari", txt(c.outcomes))}
  ${blk('topics', 'Mavzular va soatlar taqsimoti', c.topics.length ? `<div class="tbl-wrap" style="box-shadow:none"><table class="tbl"><thead><tr><th style="width:50px">№</th><th>Mavzu</th><th style="width:80px">Soat</th></tr></thead><tbody>${c.topics.map((t, i) => `<tr><td class="muted">${i + 1}</td><td>${esc(t.title)}</td><td>${t.hours}</td></tr>`).join('')}<tr><td></td><td><b>Jami</b></td><td><b>${total}</b></td></tr></tbody></table></div>` : '<span class="muted">Mavzular kiritilmagan</span>')}
  ${blk('literature', 'Adabiyotlar', txt(c.literature))}`;
}

function commentsTab(d) {
  const mine = state.user.role === 'methodist' && d.status === 'in_review';
  const rej = d.approvals.filter(a => a.decision === 'rejected');
  return `${rej.map(a => `<div class="alert bad"><b>Rahbar rad etdi</b> (v${a.version_no}, ${esc(a.head)}, ${fmtDate(a.decided_at)}):<br>${esc(a.reason)}</div>`).join('')}
  ${d.comments.length ? d.comments.map(x => `<div class="cmt ${x.status}"><div class="meta"><b>${esc(state.meta.sections[x.section] || x.section)}</b><span>v${x.version_no}</span><span>${esc(x.author)}</span><span>${fmtDT(x.created_at)}</span><span class="badge ${x.status === 'open' ? 'revision' : 'approved'}">${x.status === 'open' ? 'Ochiq' : 'Yopilgan'}</span></div><div style="white-space:pre-wrap">${esc(x.text)}</div>${mine ? `<div style="margin-top:8px"><button class="btn sm" data-act="cmtstatus" data-id="${x.id}" data-st="${x.status === 'open' ? 'closed' : 'open'}">${x.status === 'open' ? '✓ Yopish (tuzatildi)' : 'Qayta ochish'}</button></div>` : ''}</div>`).join('') : '<div class="empty">Izohlar yo\'q</div>'}`;
}

function versionsTab(d) {
  const vs = d.versions;
  return `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Versiya</th><th>Muallif</th><th>Sana</th><th>Izoh</th><th></th></tr></thead><tbody>${vs.map((v, i) => `<tr><td><b>v${v.version_no}</b> ${v.version_no === d.current_version ? badge('approved', 'joriy') : ''} ${v.locked ? '🔒' : '<span class="muted small">(tahrirlanmoqda)</span>'}</td><td>${esc(v.author)}</td><td>${fmtDT(v.created_at)}</td><td class="muted">${esc(v.note || '')}</td><td class="nowrap"><a class="btn sm" href="#/program/${d.id}?v=${v.version_no}">Ko'rish</a> ${vs[i + 1] ? `<a class="btn sm" href="#/compare/${d.id}?a=${vs[i + 1].version_no}&b=${v.version_no}">Oldingisi bilan solishtirish</a>` : ''}</td></tr>`).join('')}</tbody></table></div>`;
}
function historyTab(d) {
  return `<ul class="tl">${[...d.history].reverse().map(h => `<li><div>${h.from_status ? badge(h.from_status) + ' → ' : ''}${badge(h.to_status)} ${h.version_no ? `<span class="muted small">v${h.version_no}</span>` : ''}</div><div class="small">${esc(h.actor || 'Tizim')} · <span class="muted">${fmtDT(h.at)}</span></div>${h.note ? `<div class="muted small">${esc(h.note)}</div>` : ''}</li>`).join('')}</ul>`;
}
function filesTab(d) {
  return d.files.length ? `<ul class="files">${d.files.map(f => `<li><span>📎</span><div><a href="/api/files/${f.id}"><b>${esc(f.name)}</b></a><div class="muted small">${fmtSize(f.size)} · ${esc(f.uploader)} · ${fmtDate(f.created_at)} · SHA-256: ${f.sha256.slice(0, 12)}…</div></div></li>`).join('')}</ul>` : '<div class="empty">Biriktirilgan fayl yo\'q</div>';
}

route(/^\/program\/(\d+)$/, async (m, p) => {
  const d = await GET(`/api/programs/${m[1]}` + (p.v ? `?v=${p.v}` : '')); cur = d; const u = state.user;
  const tab = p.tab || 'content';
  const lastRej = d.status === 'rejected' && d.approvals.find(a => a.decision === 'rejected');
  const openN = d.comments.filter(c => c.status === 'open').length;
  const btnCls = { submitted: 'primary', resubmitted: 'primary', in_review: 'primary', ready: 'ok', approved: 'ok', rejected: 'danger', revision: '' };
  const acts = d.actions.map(a => `<button class="btn ${btnCls[a.to] || ''}" data-act="trans" data-to="${a.to}" data-from="${d.status}" style="width:100%;justify-content:center">${a.label}</button>`).join('');
  const meta = `<dl class="kv"><dt>Fan</dt><dd>${esc(d.subject)} <span class="muted">(${esc(d.subject_code)})</span></dd><dt>Yo'nalish</dt><dd>${esc(d.direction || '—')}</dd><dt>O'quv yili</dt><dd>${esc(d.year)}</dd><dt>Muallif</dt><dd>${esc(d.author)}</dd><dt>Metodist</dt><dd>${esc(d.reviewer || '—')}</dd><dt>Versiya</dt><dd>v${d.current_version}</dd>${d.review_due && ['submitted', 'in_review', 'resubmitted'].includes(d.status) ? `<dt>Tekshiruv muddati</dt><dd>${fmtDate(d.review_due)} <span class="${d.overdue ? 'badge over' : 'muted small'}">${daysLeft(d.review_due)}</span></dd>` : ''}${d.approval_due && d.status === 'ready' ? `<dt>Tasdiqlash muddati</dt><dd>${fmtDate(d.approval_due)} <span class="${d.overdue ? 'badge over' : 'muted small'}">${daysLeft(d.approval_due)}</span></dd>` : ''}${d.doc_code ? `<dt>Hujjat raqami</dt><dd>${esc(d.doc_code)}</dd>` : ''}<dt>Yaratilgan</dt><dd>${fmtDate(d.created_at)}</dd></dl>`;
  const tabs = [['content', 'Mazmun'], ['comments', `Izohlar${d.comments.length ? ` (${openN}/${d.comments.length})` : ''}`], ['files', `Fayllar (${d.files.length})`], ['versions', `Versiyalar (${d.versions.length})`], ['history', 'Tarix']];
  const body = { content: contentTab, comments: commentsTab, files: filesTab, versions: versionsTab, history: historyTab }[tab](d);
  return `<div class="crumbs"><a href="#/programs">Dasturlar</a> / №${d.id}</div>
  <div class="page-head"><div><h1>${esc(d.title)}</h1><div class="row" style="margin-top:8px">${badge(d.status)} ${d.overdue ? '<span class="badge over">Muddati o\'tgan</span>' : ''}<span class="muted small">v${d.current_version}${d.doc_code ? ' · ' + esc(d.doc_code) : ''}</span></div></div>
  <div class="right row">${d.can_edit ? `<a class="btn" href="#/program/${d.id}/edit">${ic('edit')} Tahrirlash</a>` : ''}${d.has_pdf ? `<a class="btn" target="_blank" href="/api/programs/${d.id}/pdf?inline=1">PDF ko'rish</a><a class="btn primary" href="/api/programs/${d.id}/pdf">${ic('down')} PDF yuklab olish</a>` : ''}</div></div>
  <div class="card" style="margin-bottom:16px">${flowHtml(d)}</div>
  ${d.status === 'revision' && u.role === 'teacher' ? `<div class="alert warn"><b>Dastur tuzatishga qaytarildi.</b> ${openN} ta izoh bor. Izohlarni ko'rib, "Tahrirlash" orqali yangi versiya saqlang, so'ng qayta yuboring. <a href="#/program/${d.id}?tab=comments">Izohlarni ko'rish →</a></div>` : ''}
  ${lastRej && u.role === 'teacher' ? `<div class="alert bad"><b>Rahbar rad etdi:</b> ${esc(lastRej.reason)}<br><span class="small">Tahrirlab yangi versiya saqlang va qayta yuboring.</span></div>` : ''}
  ${d.status === 'ready' && u.role === 'head' ? `<div class="alert info">Dastur metodik tekshiruvdan o'tgan va qaroringizni kutmoqda.</div>` : ''}
  ${!d.version.is_latest ? `<div class="alert info">Siz <b>v${d.version.no}</b> versiyasini ko'ryapsiz (eski). <a href="#/program/${d.id}">Joriy versiyaga qaytish</a></div>` : ''}
  <div class="split"><div><div class="tabs">${tabs.map(([k, l]) => `<button data-act="tab" data-tab="${k}" class="${k === tab ? 'active' : ''}">${l}</button>`).join('')}</div>${body}</div>
  <div><div class="card"><h2>Ma'lumotlar</h2>${meta}</div>${acts ? `<div class="card"><h2>Amallar</h2><div class="grid" style="gap:10px">${acts}${u.role === 'methodist' && d.status === 'in_review' ? `<div class="hint">Ochiq izohlar: <b>${openN}</b>. Rahbarga yo'naltirish uchun barcha izohlar yopilgan bo'lishi kerak.</div>` : ''}</div></div>` : ''}
  ${d.template ? `<div class="card"><h2>Shablon</h2><div class="small">${esc(d.template.name)}</div>${d.status === 'draft' && u.role === 'teacher' ? (d.problems.length ? `<div class="alert warn" style="margin:10px 0 0"><b>To'liqlik tekshiruvi:</b><ul>${d.problems.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : '<div class="alert ok" style="margin:10px 0 0">To\'liqlik tekshiruvidan o\'tdi ✓</div>') : ''}</div>` : ''}</div></div>`;
});

ACT.tab = (el) => {
  const m = location.hash.match(/^#\/program\/(\d+)(?:\?(.*))?/); const p = new URLSearchParams(m[2] || ''); p.set('tab', el.dataset.tab);
  location.hash = `#/program/${m[1]}?${p}`;
};
ACT.addcomment = async (el) => {
  const sec = el.dataset.section;
  const r = await modal({ title: `Izoh: ${state.meta.sections[sec]}`, ok: "Izoh qo'shish", body: `<div class="field"><label class="f">Bo'lim</label><select name="section">${Object.entries(state.meta.sections).map(([k, v]) => `<option value="${k}" ${k === sec ? 'selected' : ''}>${v}</option>`).join('')}</select></div><div class="field"><label class="f">Izoh matni</label><textarea name="text" required maxlength="2000" placeholder="Kamchilik va tavsiyani yozing…"></textarea></div>`, onOk: (f) => POST(`/api/programs/${cur.id}/comments`, f) });
  if (r) { toast('Izoh qo\'shildi', 'ok'); render(); }
};
ACT.cmtstatus = async (el) => { await api('PATCH', `/api/comments/${el.dataset.id}`, { status: el.dataset.st }); render(); };

ACT.trans = async (el) => {
  const to = el.dataset.to, from = el.dataset.from, d = cur; let payload = {};
  const openN = d.comments.filter(c => c.status === 'open').length;
  if (to === 'submitted') {
    if (d.problems.length) return void modal({ title: "To'liqlik tekshiruvi", ok: null, cancel: 'Yopish', body: `<div class="alert bad"><b>Dastur yuborishga tayyor emas:</b><ul>${d.problems.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` });
    payload = await modal({ title: 'Tekshiruvga yuborish', ok: 'Yuborish', body: `<div class="alert ok">To'liqlik tekshiruvidan o'tdi ✓ — v${d.current_version} yuboriladi va keyin o'zgartirib bo'lmaydi.</div><div class="field"><label class="f">Metodist</label><select name="reviewer_id"><option value="">Avtomatik (eng kam yuklangan)</option>${state.meta.methodists.map(x => `<option value="${x.id}">${esc(x.full_name)} — ${x.load} ta vazifa</option>`).join('')}</select></div>` });
    if (!payload) return;
  } else if (to === 'rejected') {
    payload = await modal({ title: 'Dasturni rad etish', ok: 'Rad etish', okClass: 'danger', body: `<div class="field"><label class="f">Rad etish sababi (majburiy)</label><textarea name="reason" required placeholder="O'qituvchi nimani tuzatishi kerakligini yozing…"></textarea></div>` });
    if (!payload) return;
  } else if (to === 'approved') {
    payload = await modal({ title: 'Dasturni tasdiqlash', ok: 'Tasdiqlash', okClass: 'ok', body: `<p style="margin-top:0">«${esc(d.title)}» (v${d.current_version}) tasdiqlanadi. PDF avtomatik shakllantirilib, elektron arxivga joylanadi va o'zgartirib bo'lmaydi.</p><div class="field"><label class="f">Izoh (ixtiyoriy)</label><textarea name="reason"></textarea></div>` });
    if (!payload) return;
  } else if (to === 'revision') {
    if (!(await confirmBox('Tuzatishga qaytarish', `Dastur o'qituvchiga izohlar bilan qaytariladi. Izohlar soni: <b>${d.comments.length}</b>.`, 'Qaytarish'))) return;
  } else if (to === 'ready') {
    if (openN) return void toast(`Hali ${openN} ta izoh yopilmagan — avval barcha izohlarni yoping`, 'err');
    if (!(await confirmBox("Rahbarga yo'naltirish", "Metodik tekshiruv yakunlanadi va dastur rahbarga yuboriladi.", "Yo'naltirish"))) return;
  } else if (to === 'resubmitted') {
    if (!(await confirmBox('Qayta yuborish', "Tuzatilgan versiya metodistga qayta yuboriladi.", 'Yuborish'))) return;
  }
  el.disabled = true;
  try {
    await POST(`/api/programs/${d.id}/transition`, { to, ...payload });
    toast(to === 'approved' ? 'Tasdiqlandi. PDF shakllantirilib, arxivga joylandi' : 'Holat yangilandi', 'ok');
    location.hash = `#/program/${d.id}`; render();
  } catch (e) {
    el.disabled = false; fail(e);
    if (e.problems) modal({ title: "To'liqlik tekshiruvi", ok: null, cancel: 'Yopish', body: `<div class="alert bad"><ul>${e.problems.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` });
  }
};
