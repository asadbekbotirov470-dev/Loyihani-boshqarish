// "Fanning o'quv dasturini tasdiqlash platformasi" — server (REST API + statik fayllar)
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const { q, now, hashPassword, verifyPassword, getSetting, allSettings, audit, verifyAuditChain, notify, tx } = require('./db');
const W = require('./lib/workflow');
const { reportPdf, ARCHIVE_DIR } = require('./lib/pdf');
const { seedIfEmpty } = require('./seed');

const { HttpError, fail } = W;
const app = express();
const UPLOAD_DIR = path.join(__dirname, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.disable('x-powered-by');
app.set('trust proxy', true);

// ---------- Xavfsizlik sarlavhalari ----------
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'",
    'Cache-Control': 'no-store',
  });
  if (process.env.COOKIE_SECURE === '1') res.set('Strict-Transport-Security', 'max-age=31536000');
  next();
});
app.use(express.json({ limit: '16mb' }));
// CSRF himoyasi: o'zgartiruvchi so'rovlar faqat JSON bo'lishi shart (+ SameSite=Strict cookie)
app.use('/api', (req, res, next) => {
  if (!['GET', 'HEAD'].includes(req.method) && !req.is('application/json')) return res.status(415).json({ error: 'JSON kerak' });
  next();
});

// ---------- Sessiyalar ----------
const cookie = (req, n) => (req.headers.cookie || '').split(';').map(s => s.trim().split('=')).find(p => p[0] === n)?.[1];
function loadUser(req) {
  const tok = cookie(req, 'sid');
  if (!tok) return null;
  const s = q.get('SELECT * FROM sessions WHERE token=?', tok);
  if (!s) return null;
  const ttl = parseInt(getSetting('session_minutes'), 10) * 60000;
  if (Date.now() - s.last_seen > ttl) { q.run('DELETE FROM sessions WHERE token=?', tok); return null; }
  q.run('UPDATE sessions SET last_seen=? WHERE token=?', Date.now(), tok);
  const u = q.get('SELECT * FROM users WHERE id=? AND active=1', s.user_id);
  if (u) u._token = tok;
  return u || null;
}
const auth = (...roles) => (req, res, next) => {
  const u = loadUser(req);
  if (!u) return res.status(401).json({ error: 'Tizimga kiring' });
  if (roles.length && !roles.includes(u.role)) return res.status(403).json({ error: "Bu amal uchun huquqingiz yo'q" });
  req.user = u; next();
};
const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch(e => {
  if (e instanceof HttpError) return res.status(e.status).json({ error: e.message, problems: e.problems });
  console.error(e); res.status(500).json({ error: 'Server xatosi' });
});
const pub = (u) => ({ id: u.id, full_name: u.full_name, login: u.login, role: u.role, email: u.email, position: u.position });
const ip = (req) => req.ip;

// ---------- Auth ----------
app.post('/api/login', wrap((req, res) => {
  const { login = '', password = '' } = req.body || {};
  const since = Date.now() - 10 * 60000;
  q.run('DELETE FROM login_attempts WHERE at<?', since);
  if (q.get('SELECT COUNT(*) n FROM login_attempts WHERE login=?', login).n >= 5) fail(429, "Juda ko'p urinish. 10 daqiqadan so'ng qayta urinib ko'ring");
  const u = q.get('SELECT * FROM users WHERE login=? AND active=1', String(login));
  if (!u || !verifyPassword(String(password), u.pass_hash)) {
    q.run('INSERT INTO login_attempts(login,at) VALUES(?,?)', login, Date.now());
    audit(null, 'login.fail', `login:${String(login).slice(0, 40)}`, '', ip(req));
    fail(401, "Login yoki parol noto'g'ri");
  }
  const tok = crypto.randomBytes(32).toString('hex');
  q.run('INSERT INTO sessions(token,user_id,created_at,last_seen,ip) VALUES(?,?,?,?,?)', tok, u.id, now(), Date.now(), ip(req));
  res.cookie('sid', tok, { httpOnly: true, sameSite: 'strict', secure: process.env.COOKIE_SECURE === '1', path: '/' });
  audit(u, 'login', `user:${u.id}`, '', ip(req));
  res.json(pub(u));
}));
app.post('/api/logout', auth(), wrap((req, res) => {
  q.run('DELETE FROM sessions WHERE token=?', req.user._token);
  audit(req.user, 'logout', `user:${req.user.id}`, '', ip(req));
  res.clearCookie('sid'); res.json({ ok: true });
}));
app.get('/api/me', auth(), (req, res) => res.json(pub(req.user)));
app.put('/api/me', auth(), wrap((req, res) => {
  const { full_name, email, position } = req.body || {};
  if (!String(full_name || '').trim()) fail(400, 'F.I.Sh. kiriting');
  q.run('UPDATE users SET full_name=?, email=?, position=? WHERE id=?', String(full_name).trim(), email || null, position || null, req.user.id);
  audit(req.user, 'profile.update', `user:${req.user.id}`, '', ip(req)); res.json({ ok: true });
}));
app.post('/api/me/password', auth(), wrap((req, res) => {
  const { old_password, new_password } = req.body || {};
  if (!verifyPassword(String(old_password || ''), req.user.pass_hash)) fail(400, "Joriy parol noto'g'ri");
  if (String(new_password || '').length < 8) fail(400, "Yangi parol kamida 8 belgidan iborat bo'lsin");
  q.run('UPDATE users SET pass_hash=? WHERE id=?', hashPassword(new_password), req.user.id);
  q.run('DELETE FROM sessions WHERE user_id=? AND token!=?', req.user.id, req.user._token);
  audit(req.user, 'password.change', `user:${req.user.id}`, '', ip(req)); res.json({ ok: true });
}));

// ---------- Meta ----------
app.get('/api/meta', auth(), (req, res) => {
  const methodists = q.all(`SELECT u.id, u.full_name, (SELECT COUNT(*) FROM curriculums c WHERE c.reviewer_id=u.id AND c.status IN ('submitted','in_review','resubmitted')) load
    FROM users u WHERE role='methodist' AND active=1 ORDER BY full_name`);
  res.json({
    status: W.STATUS, roles: W.ROLE, sections: W.SECTIONS, fields: W.FIELD_LABELS, transitions: W.TRANSITIONS,
    directions: q.all('SELECT * FROM directions ORDER BY name'), years: q.all('SELECT * FROM academic_years ORDER BY name DESC'),
    subjects: q.all('SELECT * FROM subjects ORDER BY name'), templates: q.all('SELECT * FROM templates WHERE active=1'),
    methodists, teachers: q.all("SELECT id, full_name FROM users WHERE role='teacher' ORDER BY full_name"),
    settings: { institution: getSetting('institution'), max_file_mb: getSetting('max_file_mb'), review_days: getSetting('review_days'), approval_days: getSetting('approval_days') },
  });
});

// ---------- Bildirishnomalar ----------
app.get('/api/notifications', auth(), (req, res) => {
  res.json({ items: q.all('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50', req.user.id),
    unread: q.get('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0', req.user.id).n });
});
app.post('/api/notifications/read', auth(), (req, res) => { q.run('UPDATE notifications SET read=1 WHERE user_id=?', req.user.id); res.json({ ok: true }); });

// ---------- Dasturlar: ro'yxat ----------
const BASE = `SELECT c.*, s.name subject, s.code subject_code, d.name direction, y.name year, a.full_name author, r.full_name reviewer
  FROM curriculums c JOIN subjects s ON s.id=c.subject_id LEFT JOIN directions d ON d.id=c.direction_id
  JOIN academic_years y ON y.id=c.year_id JOIN users a ON a.id=c.author_id LEFT JOIN users r ON r.id=c.reviewer_id`;

function scopeSql(user) {
  if (user.role === 'teacher') return { sql: 'c.author_id=?', p: [user.id] };
  if (user.role === 'methodist') return { sql: 'c.reviewer_id=?', p: [user.id] };
  if (user.role === 'head') return { sql: "c.status!='draft'", p: [] };
  return { sql: '1=1', p: [] };
}
function filters(query, where, p) {
  if (query.status) { where.push('c.status=?'); p.push(query.status); }
  if (query.group === 'review') where.push("c.status IN ('submitted','in_review','resubmitted')");
  if (query.group === 'returned') where.push("c.status IN ('revision','rejected')");
  if (query.group === 'approved') where.push("c.status IN ('approved','archived')");
  if (query.group === 'overdue') { where.push("((c.status IN ('submitted','in_review','resubmitted') AND c.review_due<?) OR (c.status='ready' AND c.approval_due<?))"); p.push(now(), now()); }
  if (query.year) { where.push('c.year_id=?'); p.push(+query.year); }
  if (query.subject) { where.push('c.subject_id=?'); p.push(+query.subject); }
  if (query.direction) { where.push('c.direction_id=?'); p.push(+query.direction); }
  if (query.teacher) { where.push('c.author_id=?'); p.push(+query.teacher); }
  if (query.from) { where.push('c.created_at>=?'); p.push(query.from); }
  if (query.to) { where.push('c.created_at<=?'); p.push(query.to + 'T23:59:59'); }
  if (query.q) { where.push('(s.name LIKE ? OR s.code LIKE ? OR c.doc_code LIKE ? OR a.full_name LIKE ?)'); const l = `%${query.q}%`; p.push(l, l, l, l); }
}
const decorate = (r) => ({ ...r, status_label: W.STATUS[r.status], overdue: W.isOverdue(r), pass_hash: undefined });

app.get('/api/programs', auth(), (req, res) => {
  const sc = scopeSql(req.user); const where = [sc.sql]; const p = [...sc.p];
  filters(req.query, where, p);
  res.json(q.all(`${BASE} WHERE ${where.join(' AND ')} ORDER BY c.updated_at DESC LIMIT 500`, ...p).map(decorate));
});

app.get('/api/archive', auth(), wrap((req, res) => {
  const where = ["c.status='archived'"]; const p = [];
  filters({ ...req.query, status: undefined, group: undefined }, where, p);
  res.json(q.all(`${BASE} WHERE ${where.join(' AND ')} ORDER BY c.updated_at DESC LIMIT 500`, ...p).map(decorate));
}));

app.post('/api/programs', auth('teacher'), wrap((req, res) => {
  const id = W.createCurriculum(req.user, req.body || {});
  audit(req.user, 'curriculum.create', `curriculum:${id}`, '', ip(req)); res.json({ id });
}));

// ---------- Dastur tafsilotlari ----------
function loadProgram(user, id) {
  const c = q.get(`${BASE} WHERE c.id=?`, id);
  if (!c) fail(404, 'Dastur topilmadi');
  if (!W.canView(user, c)) fail(403, "Bu dasturni ko'rish huquqingiz yo'q");
  return c;
}
app.get('/api/programs/:id', auth(), wrap((req, res) => {
  const c = loadProgram(req.user, +req.params.id);
  const versions = q.all(`SELECT v.id, v.version_no, v.locked, v.created_at, v.note, u.full_name author FROM curriculum_versions v JOIN users u ON u.id=v.created_by WHERE curriculum_id=? ORDER BY version_no DESC`, c.id);
  const want = +req.query.v || c.current_version;
  const ver = q.get('SELECT * FROM curriculum_versions WHERE curriculum_id=? AND version_no=?', c.id, want);
  if (!ver) fail(404, 'Versiya topilmadi');
  const content = W.parseContent(ver.content);
  const tpl = c.template_id ? q.get('SELECT * FROM templates WHERE id=?', c.template_id) : null;
  const comments = q.all(`SELECT cm.*, u.full_name author, v.version_no FROM comments cm JOIN users u ON u.id=cm.author_id JOIN curriculum_versions v ON v.id=cm.version_id WHERE cm.curriculum_id=? ORDER BY cm.id DESC`, c.id);
  const files = q.all('SELECT d.id,d.name,d.mime,d.size,d.sha256,d.created_at,u.full_name uploader FROM documents d JOIN users u ON u.id=d.uploaded_by WHERE curriculum_id=? ORDER BY d.id', c.id);
  const hist = q.all('SELECT h.*, u.full_name actor FROM status_history h LEFT JOIN users u ON u.id=h.actor_id WHERE curriculum_id=? ORDER BY h.id', c.id);
  const approvals = q.all('SELECT a.*, u.full_name head, v.version_no FROM approvals a JOIN users u ON u.id=a.head_id JOIN curriculum_versions v ON v.id=a.version_id WHERE a.curriculum_id=? ORDER BY a.id DESC', c.id);
  const latest = W.latestVersion(c.id);
  audit(req.user, 'curriculum.view', `curriculum:${c.id}`, `v${want}`, ip(req));
  res.json({
    ...decorate(c), content, version: { no: ver.version_no, locked: !!ver.locked, is_latest: ver.version_no === latest.version_no, editable_latest: !latest.locked },
    versions, comments, files, history: hist, approvals,
    can_edit: W.canEdit(req.user, c), actions: W.availableActions(req.user, c),
    problems: W.completeness(content, tpl), template: tpl ? { name: tpl.name, required: JSON.parse(tpl.required_fields) } : null,
    open_comments: W.openComments(c.id), has_pdf: !!c.pdf_path,
  });
}));

app.put('/api/programs/:id/content', auth('teacher'), wrap((req, res) => {
  res.json(W.saveContent(req.user, +req.params.id, req.body && req.body.content, ip(req)));
}));

app.post('/api/programs/:id/transition', auth(), wrap(async (req, res) => {
  const id = +req.params.id; const { to } = req.body || {};
  const c = q.get('SELECT * FROM curriculums WHERE id=?', id);
  if (!c) fail(404, 'Dastur topilmadi');
  if (!W.canView(req.user, c)) fail(403, "Huquqingiz yo'q");
  if (req.user.role === 'admin') fail(403, "Administrator tasdiqlash jarayoniga aralasha olmaydi");
  const r = W.transition(req.user, id, to, req.body, ip(req));
  if (to === 'approved') await W.finalizeApproval(id, ip(req));
  res.json(r);
}));

// ---------- Izohlar ----------
app.post('/api/programs/:id/comments', auth('methodist'), wrap((req, res) => {
  loadProgram(req.user, +req.params.id);
  res.json({ id: W.addComment(req.user, +req.params.id, req.body.section, req.body.text, ip(req)) });
}));
app.patch('/api/comments/:id', auth('methodist'), wrap((req, res) => {
  const st = req.body.status === 'open' ? 'open' : 'closed';
  W.setCommentStatus(req.user, +req.params.id, st, ip(req)); res.json({ ok: true });
}));

// ---------- Fayllar ----------
const MAGIC = { pdf: b => b.slice(0, 4).toString() === '%PDF', docx: b => b[0] === 0x50 && b[1] === 0x4b, xlsx: b => b[0] === 0x50 && b[1] === 0x4b,
  png: b => b[0] === 0x89 && b.slice(1, 4).toString() === 'PNG', jpg: b => b[0] === 0xff && b[1] === 0xd8, jpeg: b => b[0] === 0xff && b[1] === 0xd8 };
const MIME = { pdf: 'application/pdf', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg' };
app.post('/api/programs/:id/files', auth('teacher'), wrap((req, res) => {
  const c = loadProgram(req.user, +req.params.id);
  if (!W.canEdit(req.user, c)) fail(403, 'Hozir fayl biriktirib bo\'lmaydi');
  const name = path.basename(String(req.body.name || 'fayl')).slice(0, 120);
  const ext = path.extname(name).slice(1).toLowerCase();
  if (!MAGIC[ext]) fail(400, 'Ruxsat etilgan turlar: PDF, DOCX, XLSX, PNG, JPG');
  const buf = Buffer.from(String(req.body.data || ''), 'base64');
  const max = parseInt(getSetting('max_file_mb'), 10) * 1048576;
  if (!buf.length) fail(400, "Fayl bo'sh");
  if (buf.length > max) fail(413, `Fayl hajmi ${getSetting('max_file_mb')} MB dan oshmasligi kerak`);
  if (!MAGIC[ext](buf)) fail(400, 'Fayl mazmuni kengaytmasiga mos emas');
  const stored = crypto.randomBytes(16).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(UPLOAD_DIR, stored), buf);
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  const r = q.run('INSERT INTO documents(curriculum_id,name,mime,size,path,sha256,uploaded_by,created_at) VALUES(?,?,?,?,?,?,?,?)', c.id, name, MIME[ext], buf.length, stored, sha, req.user.id, now());
  audit(req.user, 'file.upload', `curriculum:${c.id}`, name, ip(req)); res.json({ id: Number(r.lastInsertRowid) });
}));
app.get('/api/files/:id', auth(), wrap((req, res) => {
  const d = q.get('SELECT * FROM documents WHERE id=?', +req.params.id);
  if (!d) fail(404, 'Fayl topilmadi');
  loadProgram(req.user, d.curriculum_id);
  audit(req.user, 'file.download', `curriculum:${d.curriculum_id}`, d.name, ip(req));
  res.download(path.join(UPLOAD_DIR, d.path), d.name);
}));
app.delete('/api/files/:id', auth('teacher'), wrap((req, res) => {
  const d = q.get('SELECT * FROM documents WHERE id=?', +req.params.id);
  if (!d) fail(404, 'Fayl topilmadi');
  const c = loadProgram(req.user, d.curriculum_id);
  if (!W.canEdit(req.user, c)) fail(403, "Hozir faylni o'chirib bo'lmaydi");
  q.run('DELETE FROM documents WHERE id=?', d.id); try { fs.unlinkSync(path.join(UPLOAD_DIR, d.path)); } catch {}
  audit(req.user, 'file.delete', `curriculum:${c.id}`, d.name, ip(req)); res.json({ ok: true });
}));

// ---------- Arxivdan PDF ----------
app.get('/api/programs/:id/pdf', auth(), wrap((req, res) => {
  const c = loadProgram(req.user, +req.params.id);
  if (!c.pdf_path) fail(404, 'PDF hali shakllantirilmagan');
  const buf = fs.readFileSync(c.pdf_path);
  const ok = crypto.createHash('sha256').update(buf).digest('hex') === c.pdf_hash;
  audit(req.user, 'archive.download', `curriculum:${c.id}`, ok ? 'butunlik: OK' : 'BUTUNLIK BUZILGAN', ip(req));
  if (!ok) fail(500, "Arxiv fayli butunligi buzilgan! Administratorga murojaat qiling");
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `${req.query.inline ? 'inline' : 'attachment'}; filename="${c.doc_code}.pdf"` });
  res.send(buf);
}));

// ---------- Dashboard ----------
app.get('/api/dashboard', auth(), (req, res) => {
  const sc = scopeSql(req.user);
  const rows = q.all(`${BASE} WHERE ${sc.sql}`, ...sc.p);
  const cnt = (f) => rows.filter(f).length;
  const stats = {
    total: rows.length, draft: cnt(r => r.status === 'draft'),
    review: cnt(r => ['submitted', 'in_review', 'resubmitted'].includes(r.status)),
    ready: cnt(r => r.status === 'ready'),
    returned: cnt(r => ['revision', 'rejected'].includes(r.status)),
    overdue: cnt(r => W.isOverdue(r)), approved: cnt(r => ['approved', 'archived'].includes(r.status)),
  };
  // Foydalanuvchining kutilayotgan vazifalari
  const todoStatus = { teacher: ['revision', 'rejected', 'draft'], methodist: ['submitted', 'resubmitted', 'in_review'], head: ['ready'], admin: [] }[req.user.role];
  const todo = rows.filter(r => todoStatus.includes(r.status)).sort((a, b) => (a.review_due || a.approval_due || 'z').localeCompare(b.review_due || b.approval_due || 'z')).slice(0, 8).map(decorate);
  const activity = q.all(`SELECT h.*, c.title, u.full_name actor FROM status_history h JOIN curriculums c ON c.id=h.curriculum_id LEFT JOIN users u ON u.id=h.actor_id
    WHERE ${sc.sql.replace(/c\./g, 'c.')} ORDER BY h.id DESC LIMIT 8`, ...sc.p);
  res.json({ stats, todo, activity });
});

// ---------- Hisobotlar ----------
function reportData(user, query) {
  const where = ["c.status!='draft' OR 1=1"]; where.length = 0; where.push('1=1'); const p = [];
  const sc = user.role === 'head' || user.role === 'admin' ? null : scopeSql(user);
  if (sc) { where.push(sc.sql); p.push(...sc.p); }
  filters(query, where, p);
  const rows = q.all(`${BASE} WHERE ${where.join(' AND ')} ORDER BY c.id`, ...p).map(decorate);
  const by = (key) => { const m = {}; rows.forEach(r => { m[r[key]] = (m[r[key]] || 0) + 1; }); return Object.entries(m).map(([name, n]) => ({ name, n })).sort((a, b) => b.n - a.n); };
  const byStatus = Object.entries(W.STATUS).map(([k, name]) => ({ key: k, name, n: rows.filter(r => r.status === k).length }));
  // Bosqichlar bo'yicha o'rtacha davomiylik (kunlarda)
  const ids = rows.map(r => r.id);
  const durs = {};
  if (ids.length) {
    const hist = q.all(`SELECT * FROM status_history WHERE curriculum_id IN (${ids.join(',')}) ORDER BY curriculum_id, id`);
    for (let i = 1; i < hist.length; i++) {
      if (hist[i].curriculum_id !== hist[i - 1].curriculum_id) continue;
      const st = hist[i].from_status; const d = (new Date(hist[i].at) - new Date(hist[i - 1].at)) / 86400000;
      (durs[st] = durs[st] || []).push(d);
    }
  }
  const stageAvg = Object.entries(W.STATUS).filter(([k]) => durs[k]).map(([k, name]) => ({ key: k, name, days: +(durs[k].reduce((a, b) => a + b, 0) / durs[k].length).toFixed(2), n: durs[k].length }));
  const approvedRows = rows.filter(r => ['approved', 'archived'].includes(r.status));
  let avgTotal = null;
  if (approvedRows.length) {
    const t = approvedRows.map(r => { const a = q.get("SELECT decided_at FROM approvals WHERE curriculum_id=? AND decision='approved' ORDER BY id DESC LIMIT 1", r.id); return a ? (new Date(a.decided_at) - new Date(r.created_at)) / 86400000 : null; }).filter(x => x != null);
    if (t.length) avgTotal = +(t.reduce((a, b) => a + b, 0) / t.length).toFixed(2);
  }
  const returns = rows.length ? q.get(`SELECT COUNT(*) n FROM status_history WHERE to_status IN ('revision','rejected') AND curriculum_id IN (${ids.join(',') || 0})`).n : 0;
  return {
    rows, summary: {
      total: rows.length, approved: approvedRows.length, in_review: rows.filter(r => ['submitted', 'in_review', 'resubmitted', 'ready'].includes(r.status)).length,
      returned_now: rows.filter(r => ['revision', 'rejected'].includes(r.status)).length, rejected_now: rows.filter(r => r.status === 'rejected').length,
      overdue: rows.filter(r => r.overdue).length, avg_total_days: avgTotal, avg_returns: rows.length ? +(returns / rows.length).toFixed(2) : 0,
    },
    byStatus, bySubject: by('subject'), byTeacher: by('author'), byYear: by('year'), byDirection: by('direction'), stageAvg,
  };
}
app.get('/api/reports', auth('head', 'admin', 'methodist', 'teacher'), (req, res) => res.json(reportData(req.user, req.query)));
app.get('/api/reports/export.xlsx', auth('head', 'admin', 'methodist', 'teacher'), wrap(async (req, res) => {
  const d = reportData(req.user, req.query);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("O'quv dasturlari");
  ws.columns = [{ header: '№', key: 'id', width: 6 }, { header: 'Fan', key: 'subject', width: 36 }, { header: 'Kod', key: 'code', width: 12 }, { header: "Yo'nalish", key: 'direction', width: 30 },
    { header: "O'quv yili", key: 'year', width: 12 }, { header: "O'qituvchi", key: 'author', width: 28 }, { header: 'Metodist', key: 'reviewer', width: 28 },
    { header: 'Holat', key: 'status', width: 24 }, { header: 'Versiya', key: 'v', width: 9 }, { header: 'Muddati o\'tgan', key: 'od', width: 14 }, { header: 'Hujjat raqami', key: 'doc', width: 16 }];
  d.rows.forEach(r => ws.addRow({ id: r.id, subject: r.subject, code: r.subject_code, direction: r.direction, year: r.year, author: r.author, reviewer: r.reviewer || '', status: r.status_label, v: 'v' + r.current_version, od: r.overdue ? 'Ha' : "Yo'q", doc: r.doc_code || '' }));
  ws.getRow(1).font = { bold: true }; ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8EEF7' } }; ws.views = [{ state: 'frozen', ySplit: 1 }];
  const ws2 = wb.addWorksheet('Statistika');
  ws2.columns = [{ header: "Ko'rsatkich", key: 'k', width: 44 }, { header: 'Qiymat', key: 'v', width: 16 }];
  const s = d.summary;
  [['Jami dasturlar', s.total], ['Tasdiqlangan', s.approved], ['Jarayondagi', s.in_review], ['Hozir tuzatishda/rad etilgan', s.returned_now], ["Muddati o'tgan", s.overdue],
    ["Tasdiqlashning o'rtacha davomiyligi (kun)", s.avg_total_days ?? '—'], ['Bitta dasturga o\'rtacha qaytarishlar', s.avg_returns],
    ...d.stageAvg.map(x => [`Bosqich: ${x.name} (o'rtacha kun)`, x.days])].forEach(r => ws2.addRow(r));
  ws2.getRow(1).font = { bold: true };
  audit(req.user, 'report.export', 'xlsx', '', ip(req));
  res.set({ 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': 'attachment; filename="hisobot.xlsx"' });
  await wb.xlsx.write(res); res.end();
}));
app.get('/api/reports/export.pdf', auth('head', 'admin', 'methodist', 'teacher'), wrap((req, res) => {
  const d = reportData(req.user, req.query);
  audit(req.user, 'report.export', 'pdf', '', ip(req));
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': 'attachment; filename="hisobot.pdf"' });
  reportPdf(res, "O'quv dasturlari bo'yicha hisobot", d.rows.map(r => [r.id, r.subject, r.year, r.author, r.reviewer || '—', r.status_label + (r.overdue ? ' (muddati o\'tgan)' : '')]), ['№', 'Fan', "O'quv yili", "O'qituvchi", 'Metodist', 'Holat']);
}));

// ---------- Administrator ----------
const adm = auth('admin');
app.get('/api/admin/users', adm, (req, res) => res.json(q.all('SELECT id,full_name,login,role,email,position,active,created_at FROM users ORDER BY role, full_name')));
app.post('/api/admin/users', adm, wrap((req, res) => {
  const { full_name, login, password, role, email, position } = req.body || {};
  if (!full_name || !login || !W.ROLE[role]) fail(400, "F.I.Sh., login va rolni to'ldiring");
  if (String(password || '').length < 8) fail(400, "Parol kamida 8 belgi bo'lsin");
  if (q.get('SELECT id FROM users WHERE login=?', login)) fail(409, 'Bunday login mavjud');
  const r = q.run('INSERT INTO users(full_name,login,pass_hash,role,email,position,created_at) VALUES(?,?,?,?,?,?,?)', full_name.trim(), login.trim(), hashPassword(password), role, email || null, position || null, now());
  audit(req.user, 'user.create', `user:${r.lastInsertRowid}`, `${login}/${role}`, ip(req)); res.json({ id: Number(r.lastInsertRowid) });
}));
app.put('/api/admin/users/:id', adm, wrap((req, res) => {
  const u = q.get('SELECT * FROM users WHERE id=?', +req.params.id); if (!u) fail(404, 'Topilmadi');
  const { full_name, role, email, position, active, password } = req.body || {};
  if (u.id === req.user.id && (active === 0 || (role && role !== 'admin'))) fail(400, "O'zingizning huquqingizni kamaytira olmaysiz");
  if (role && !W.ROLE[role]) fail(400, 'Rol noto\'g\'ri');
  q.run('UPDATE users SET full_name=?, role=?, email=?, position=?, active=? WHERE id=?', full_name || u.full_name, role || u.role, email ?? u.email, position ?? u.position, active === undefined ? u.active : (active ? 1 : 0), u.id);
  if (password) { if (password.length < 8) fail(400, "Parol kamida 8 belgi"); q.run('UPDATE users SET pass_hash=? WHERE id=?', hashPassword(password), u.id); q.run('DELETE FROM sessions WHERE user_id=?', u.id); }
  if (active === 0) q.run('DELETE FROM sessions WHERE user_id=?', u.id);
  audit(req.user, 'user.update', `user:${u.id}`, role ? `rol: ${role}` : (active === 0 ? 'bloklandi' : ''), ip(req)); res.json({ ok: true });
}));

function crud(table, route, fields, label) {
  app.post(`/api/admin/${route}`, adm, wrap((req, res) => {
    for (const f of fields) if (req.body[f.k] === undefined || (f.req && !String(req.body[f.k]).trim())) fail(400, `"${f.l}" maydonini to'ldiring`);
    const r = q.run(`INSERT INTO ${table}(${fields.map(f => f.k).join(',')}) VALUES(${fields.map(() => '?').join(',')})`, ...fields.map(f => f.json ? JSON.stringify(req.body[f.k]) : (req.body[f.k] === '' ? null : req.body[f.k])));
    audit(req.user, `${label}.create`, `${table}:${r.lastInsertRowid}`, '', ip(req)); res.json({ id: Number(r.lastInsertRowid) });
  }));
  app.put(`/api/admin/${route}/:id`, adm, wrap((req, res) => {
    q.run(`UPDATE ${table} SET ${fields.map(f => f.k + '=?').join(',')} WHERE id=?`, ...fields.map(f => f.json ? JSON.stringify(req.body[f.k]) : (req.body[f.k] === '' ? null : req.body[f.k])), +req.params.id);
    audit(req.user, `${label}.update`, `${table}:${req.params.id}`, '', ip(req)); res.json({ ok: true });
  }));
  app.delete(`/api/admin/${route}/:id`, adm, wrap((req, res) => {
    try { q.run(`DELETE FROM ${table} WHERE id=?`, +req.params.id); } catch { fail(409, "Bu yozuv boshqa ma'lumotlarga bog'langan — o'chirib bo'lmaydi"); }
    audit(req.user, `${label}.delete`, `${table}:${req.params.id}`, '', ip(req)); res.json({ ok: true });
  }));
}
crud('directions', 'directions', [{ k: 'name', l: 'Nomi', req: 1 }, { k: 'code', l: 'Kodi', req: 1 }], 'direction');
crud('academic_years', 'years', [{ k: 'name', l: 'Nomi', req: 1 }, { k: 'start_date', l: 'Boshlanish' }, { k: 'end_date', l: 'Tugash' }], 'year');
crud('subjects', 'subjects', [{ k: 'name', l: 'Fan nomi', req: 1 }, { k: 'code', l: 'Kodi', req: 1 }, { k: 'direction_id', l: "Yo'nalish" }], 'subject');
crud('templates', 'templates', [{ k: 'name', l: 'Nomi', req: 1 }, { k: 'required_fields', l: 'Majburiy maydonlar', json: 1 }, { k: 'valid_until', l: 'Amal qilish muddati' }, { k: 'active', l: 'Faol' }], 'template');
app.get('/api/admin/templates', adm, (req, res) => res.json(q.all('SELECT * FROM templates').map(t => ({ ...t, required_fields: JSON.parse(t.required_fields) }))));

app.get('/api/admin/settings', adm, (req, res) => res.json(allSettings()));
app.put('/api/admin/settings', adm, wrap((req, res) => {
  for (const k of ['review_days', 'approval_days', 'session_minutes', 'institution', 'max_file_mb']) {
    if (req.body[k] === undefined) continue;
    if (k !== 'institution' && !(parseInt(req.body[k], 10) > 0)) fail(400, `"${k}" musbat son bo'lsin`);
    q.run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', k, String(req.body[k]));
  }
  audit(req.user, 'settings.update', 'settings', '', ip(req)); res.json({ ok: true });
}));
app.get('/api/admin/audit', adm, (req, res) => {
  const where = ['1=1']; const p = [];
  if (req.query.action) { where.push('action LIKE ?'); p.push(req.query.action + '%'); }
  if (req.query.q) { where.push('(user_name LIKE ? OR object LIKE ? OR detail LIKE ?)'); const l = `%${req.query.q}%`; p.push(l, l, l); }
  res.json({ rows: q.all(`SELECT id,user_name,action,object,detail,ip,at FROM audit_log WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT 300`, ...p), chain: verifyAuditChain() });
});
app.get('/api/admin/health', adm, (req, res) => res.json({
  users: q.get('SELECT COUNT(*) n FROM users').n, programs: q.get('SELECT COUNT(*) n FROM curriculums').n,
  sessions: q.get('SELECT COUNT(*) n FROM sessions').n, audit: q.get('SELECT COUNT(*) n FROM audit_log').n, chain: verifyAuditChain(), uptime: Math.round(process.uptime()),
}));

// ---------- Ommaviy: hujjat haqiqiyligini tekshirish (QR-kod) ----------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
app.get('/verify/:code', (req, res) => {
  const c = q.get(`${BASE} WHERE c.doc_code=? AND c.status='archived'`, req.params.code);
  let ok = false, body;
  if (c) {
    try { ok = crypto.createHash('sha256').update(fs.readFileSync(c.pdf_path)).digest('hex') === c.pdf_hash; } catch {}
    const ap = q.get("SELECT a.decided_at, u.full_name head FROM approvals a JOIN users u ON u.id=a.head_id WHERE a.curriculum_id=? AND a.decision='approved' ORDER BY a.id DESC LIMIT 1", c.id);
    body = `<h1 class="${ok ? 'ok' : 'bad'}">${ok ? '✓ Hujjat haqiqiy' : '✗ Hujjat butunligi buzilgan'}</h1><dl><dt>Hujjat raqami</dt><dd>${esc(c.doc_code)}</dd><dt>Fan</dt><dd>${esc(c.subject)}</dd><dt>O'quv yili</dt><dd>${esc(c.year)}</dd><dt>Muallif</dt><dd>${esc(c.author)}</dd><dt>Tasdiqlagan</dt><dd>${esc(ap.head)}</dd><dt>Sana</dt><dd>${esc(ap.decided_at.slice(0, 10))}</dd></dl>`;
  } else body = `<h1 class="bad">✗ Bunday hujjat topilmadi</h1><p>Kod: ${esc(req.params.code)}</p>`;
  res.set('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'").type('html').send(`<!doctype html><html lang="uz"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hujjatni tekshirish</title><style>body{font:16px system-ui;max-width:520px;margin:12vh auto;padding:0 20px;color:#16202e}h1{font-size:24px}.ok{color:#14733f}.bad{color:#b3261e}dl{display:grid;grid-template-columns:130px 1fr;gap:8px 12px;background:#f4f6fa;padding:18px;border-radius:12px}dt{color:#5b6879}dd{margin:0;font-weight:600}</style>${body}`);
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Topilmadi' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0 }));
app.use((req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

seedIfEmpty().then(() => {
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Platforma ishga tushdi: http://localhost:${port}`));
});
