// Dastur tahrirlash formasi va versiyalarni solishtirish
'use strict';

let E = null; // tahrirlash holati { d, c }

function topicRows() {
  return E.c.topics.map((t, i) => `<tr><td class="n">${i + 1}</td><td><input type="text" data-ti="${i}" data-f="title" value="${esc(t.title)}" maxlength="300" placeholder="Mavzu nomi"></td><td class="h"><input type="number" min="0" max="1000" data-ti="${i}" data-f="hours" value="${t.hours || ''}" placeholder="soat"></td><td class="a"><button type="button" class="btn sm ghost" data-act="t-up" data-i="${i}" title="Yuqoriga">${ic('up')}</button><button type="button" class="btn sm ghost" data-act="t-dn" data-i="${i}" title="Pastga">${ic('dn')}</button><button type="button" class="btn sm ghost" data-act="t-del" data-i="${i}" title="O'chirish">${ic('trash')}</button></td></tr>`).join('');
}
function sumBar() {
  const sum = E.c.topics.reduce((a, t) => a + (+t.hours || 0), 0), tot = +E.c.total_hours || 0;
  const ok = tot > 0 && sum === tot;
  return `<div class="sumbar ${E.c.topics.length ? (ok ? 'ok' : 'bad') : ''}"><span>Mavzular soati: ${sum}</span><span>Umumiy soat: ${tot || '—'}</span><span class="right">${!E.c.topics.length ? '' : ok ? '✓ Mos' : tot ? `Farq: ${sum - tot > 0 ? '+' : ''}${sum - tot}` : 'Umumiy soatni kiriting'}</span></div>`;
}
function liveCheck() {
  const c = E.c, req = E.d.template ? E.d.template.required : Object.keys(state.meta.fields); const P = [];
  for (const f of req) { const v = c[f]; const empty = f === 'topics' ? !v.length : f === 'total_hours' ? !(+v > 0) : !String(v || '').trim(); if (empty) P.push(`"${state.meta.fields[f]}" to'ldirilmagan`); }
  const sum = c.topics.reduce((a, t) => a + (+t.hours || 0), 0);
  if (c.topics.length && +c.total_hours > 0 && sum !== +c.total_hours) P.push(`Soatlar yig'indisi (${sum}) umumiy soatga (${c.total_hours}) mos emas`);
  if (c.topics.some(t => !t.title.trim())) P.push("Nomi bo'sh mavzu bor");
  return P;
}
function refreshLive() {
  const sb = $('#sumbar'); if (sb) sb.innerHTML = sumBar();
  const P = liveCheck(); const lc = $('#livecheck');
  if (lc) lc.innerHTML = P.length ? `<div class="alert warn" style="margin:0"><b>Hali to'ldirilmagan (${P.length}):</b><ul>${P.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>` : '<div class="alert ok" style="margin:0">To\'liqlik tekshiruvidan o\'tdi ✓ Yuborishga tayyor.</div>';
}
const setDirty = (v) => { state.dirty = v; const s = $('#savestate'); if (s) s.textContent = v ? "● Saqlanmagan o'zgarishlar bor" : '✓ Hamma o\'zgarishlar saqlangan'; };

route(/^\/program\/(\d+)\/edit$/, async (m) => {
  const d = await GET(`/api/programs/${m[1]}`);
  if (!d.can_edit) { location.hash = `#/program/${d.id}`; return ''; }
  E = { d, c: JSON.parse(JSON.stringify(d.content)) };
  if (!E.c.topics.length && d.status === 'draft') E.c.topics = [{ title: '', hours: 0 }];
  const willFork = !d.version.editable_latest;
  const openC = d.comments.filter(c => c.status === 'open');
  const rej = d.status === 'rejected' && d.approvals.find(a => a.decision === 'rejected');
  const ta = (k, label, ph, rows = 5) => `<div class="card"><div class="field" style="margin:0"><label class="f" for="f-${k}">${label}</label><textarea id="f-${k}" data-f="${k}" rows="${rows}" style="min-height:${rows * 24}px" placeholder="${ph}">${esc(E.c[k])}</textarea></div></div>`;
  return `<div class="crumbs"><a href="#/programs">Dasturlar</a> / <a href="#/program/${d.id}">№${d.id}</a> / Tahrirlash</div>
  <div class="page-head"><div><h1>${esc(d.title)}</h1><p>${badge(d.status)} · ${willFork ? `Saqlasangiz <b>yangi versiya (v${d.current_version + 1})</b> yaratiladi` : `Joriy versiya: v${d.current_version} (qoralama)`}</p></div></div>
  ${rej ? `<div class="alert bad"><b>Rahbar rad etdi:</b> ${esc(rej.reason)}</div>` : ''}
  ${openC.length ? `<div class="alert warn"><b>Metodist izohlari (${openC.length}):</b><ul>${openC.map(c => `<li><b>${esc(state.meta.sections[c.section])}:</b> ${esc(c.text)}</li>`).join('')}</ul></div>` : ''}
  <div class="split"><form id="ef" autocomplete="off">
    <div class="card"><h2>1. Asosiy ma'lumotlar</h2><div class="grid g4"><div class="field" style="margin:0"><label class="f">Fan</label><input type="text" value="${esc(d.subject)}" disabled></div>
    <div class="field" style="margin:0"><label class="f" for="f-course">Kurs</label><select id="f-course" data-f="course"><option value="">—</option>${[1, 2, 3, 4, 5, 6].map(n => `<option ${E.c.course === String(n) ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div class="field" style="margin:0"><label class="f" for="f-semester">Semestr</label><select id="f-semester" data-f="semester"><option value="">—</option>${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(n => `<option ${E.c.semester === String(n) ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div class="field" style="margin:0"><label class="f" for="f-total">Umumiy soat</label><input id="f-total" type="number" min="0" max="5000" data-f="total_hours" value="${E.c.total_hours || ''}"></div></div></div>
    ${ta('goals', '2. Fan o\'qitilishining maqsadi', "Fanni o'qitishdan maqsad nima?")}
    ${ta('objectives', '3. Fanning vazifalari', "Har bir vazifani yangi qatordan yozing", 5)}
    ${ta('outcomes', "4. Kutilayotgan o'quv natijalari", "Talaba nimani bilishi va qo'llay olishi kerak?", 5)}
    <div class="card"><h2>5. Mavzular va soatlar taqsimoti</h2><table class="topics-tbl"><tbody id="topics">${topicRows()}</tbody></table><div class="row" style="margin-top:8px"><button type="button" class="btn sm" data-act="t-add">${ic('plus')} Mavzu qo'shish</button></div><div id="sumbar">${sumBar()}</div></div>
    ${ta('literature', '6. Adabiyotlar', "Asosiy va qo'shimcha adabiyotlar ro'yxati", 5)}
    <div class="card"><h2>7. Qo'shimcha fayllar</h2><div id="filebox"></div><div style="margin-top:12px"><input type="file" id="fup" multiple accept=".pdf,.docx,.xlsx,.png,.jpg,.jpeg" class="hidden"><button type="button" class="btn" data-act="pickfile">${ic('plus')} Fayl biriktirish</button> <span class="hint">PDF, DOCX, XLSX, PNG, JPG · ${state.meta.settings.max_file_mb} MB gacha</span></div></div>
    <div class="savebar"><button type="button" class="btn primary" data-act="save">Saqlash</button><a class="btn" href="#/program/${d.id}">Dasturga qaytish</a><span id="savestate" class="muted small">✓ Hamma o'zgarishlar saqlangan</span></div>
  </form>
  <div style="position:sticky;top:76px"><div class="card"><h2>To'liqlik tekshiruvi</h2><div id="livecheck"></div></div><div class="card"><h2>Maslahat</h2><p class="small muted" style="margin:0">Ctrl+S — saqlash. Mavzular soatlari yig'indisi umumiy soatga teng bo'lishi shart. Tekshiruvga yuborish dastur sahifasidagi "Amallar" bo'limida.</p></div></div></div>`;
}, { roles: ['teacher'], after: () => { if (E) { refreshLive(); loadFiles(); setDirty(false); } } });

async function loadFiles() {
  const d = await GET(`/api/programs/${E.d.id}`); const box = $('#filebox'); if (!box) return;
  box.innerHTML = d.files.length ? `<ul class="files">${d.files.map(f => `<li><span>📎</span><div style="flex:1"><a href="/api/files/${f.id}"><b>${esc(f.name)}</b></a><div class="muted small">${fmtSize(f.size)} · ${fmtDate(f.created_at)}</div></div><button type="button" class="btn sm ghost" data-act="delfile" data-id="${f.id}">${ic('trash')}</button></li>`).join('')}</ul>` : '<div class="muted small">Fayl biriktirilmagan</div>';
}

document.addEventListener('input', (e) => {
  const t = e.target; if (!E || !t.dataset || !t.dataset.f || !$('#ef')) return;
  if (t.dataset.ti !== undefined) { const row = E.c.topics[+t.dataset.ti]; row[t.dataset.f] = t.dataset.f === 'hours' ? (parseInt(t.value, 10) || 0) : t.value; }
  else E.c[t.dataset.f] = t.type === 'number' ? (parseInt(t.value, 10) || 0) : t.value;
  setDirty(true); refreshLive();
});
const redrawTopics = () => { $('#topics').innerHTML = topicRows(); refreshLive(); setDirty(true); };
ACT['t-add'] = () => { E.c.topics.push({ title: '', hours: 0 }); redrawTopics(); const ins = $$('#topics input[data-f=title]'); ins[ins.length - 1].focus(); };
ACT['t-del'] = (el) => { E.c.topics.splice(+el.dataset.i, 1); redrawTopics(); };
ACT['t-up'] = (el) => { const i = +el.dataset.i; if (i > 0) { [E.c.topics[i - 1], E.c.topics[i]] = [E.c.topics[i], E.c.topics[i - 1]]; redrawTopics(); } };
ACT['t-dn'] = (el) => { const i = +el.dataset.i, T = E.c.topics; if (i < T.length - 1) { [T[i + 1], T[i]] = [T[i], T[i + 1]]; redrawTopics(); } };
ACT.save = async (el) => {
  if (!E) return; el.disabled = true;
  try {
    const r = await PUT(`/api/programs/${E.d.id}/content`, { content: { ...E.c, topics: E.c.topics.filter(t => t.title.trim() || t.hours) } });
    setDirty(false); toast(`Saqlandi (v${r.version_no})`, 'ok');
    if (r.version_no !== E.d.current_version) { location.hash = `#/program/${E.d.id}/edit`; render(); }
  } finally { el.disabled = false; }
};
document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 's' && $('#ef')) { e.preventDefault(); ACT.save($('[data-act=save]')).catch(fail); } });
ACT.pickfile = () => $('#fup').click();
document.addEventListener('change', async (e) => {
  if (e.target.id !== 'fup') return;
  for (const f of e.target.files) {
    if (f.size > (+state.meta.settings.max_file_mb) * 1048576) { toast(`${f.name}: hajmi katta`, 'err'); continue; }
    const data = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); });
    try { await POST(`/api/programs/${E.d.id}/files`, { name: f.name, data }); toast(`${f.name} biriktirildi`, 'ok'); } catch (err) { fail(err); }
  }
  e.target.value = ''; loadFiles();
});
ACT.delfile = async (el) => { if (await confirmBox("Faylni o'chirish", "Fayl dasturdan olib tashlanadi.", "O'chirish", 'danger')) { await DEL(`/api/files/${el.dataset.id}`); loadFiles(); } };

// ---------- Versiyalarni solishtirish ----------
function diffWords(a, b) {
  const A = a.split(/(\s+)/).filter(x => x !== ''), B = b.split(/(\s+)/).filter(x => x !== '');
  if (A.length * B.length > 4e6) return a === b ? esc(b) : `<del>${esc(a)}</del> <ins>${esc(b)}</ins>`;
  const n = A.length, m = B.length, L = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  let i = 0, j = 0, out = '', mode = '';
  const push = (t, k) => { out += k === mode ? esc(t) : `${mode ? `</${mode}>` : ''}${k ? `<${k}>` : ''}${esc(t)}`; mode = k; };
  while (i < n && j < m) {
    if (A[i] === B[j]) { push(B[j], ''); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) { push(A[i], 'del'); i++; } else { push(B[j], 'ins'); j++; }
  }
  while (i < n) push(A[i++], 'del'); while (j < m) push(B[j++], 'ins');
  if (mode) out += `</${mode}>`; return out;
}

route(/^\/compare\/(\d+)$/, async (m, p) => {
  const id = m[1]; const base = await GET(`/api/programs/${id}`);
  const nos = base.versions.map(v => v.version_no);
  const a = +p.a || nos[nos.length - 1], b = +p.b || nos[0];
  const [A, B] = await Promise.all([GET(`/api/programs/${id}?v=${a}`), GET(`/api/programs/${id}?v=${b}`)]);
  const sel = (n, v) => `<select name="${n}">${nos.map(x => `<option value="${x}" ${x === v ? 'selected' : ''}>v${x}</option>`).join('')}</select>`;
  const ca = A.content, cb = B.content;
  const txt = (k, l) => { const same = ca[k] === cb[k]; return `<div class="sec-block"><div class="hd"><h3>${l}</h3><span class="badge ${same ? '' : 'revision'}">${same ? 'O\'zgarmagan' : 'O\'zgargan'}</span></div><div class="diffbox">${cb[k] || ca[k] ? diffWords(ca[k] || '', cb[k] || '') : '<span class="muted">Bo\'sh</span>'}</div></div>`; };
  const prm = [['course', 'Kurs'], ['semester', 'Semestr'], ['total_hours', 'Umumiy soat']].map(([k, l]) => ca[k] === cb[k] ? `<div><div class="muted small">${l}</div><b>${esc(cb[k])}</b></div>` : `<div><div class="muted small">${l}</div><del>${esc(ca[k])}</del> <ins>${esc(cb[k])}</ins></div>`).join('');
  const mapA = new Map(ca.topics.map(t => [t.title, t.hours])); const mapB = new Map(cb.topics.map(t => [t.title, t.hours]));
  const trows = [...cb.topics.map(t => !mapA.has(t.title) ? [t.title, '', t.hours, 'ins'] : mapA.get(t.title) !== t.hours ? [t.title, mapA.get(t.title), t.hours, 'chg'] : [t.title, t.hours, t.hours, '']), ...ca.topics.filter(t => !mapB.has(t.title)).map(t => [t.title, t.hours, '', 'del'])];
  const sa = ca.topics.reduce((x, t) => x + t.hours, 0), sb = cb.topics.reduce((x, t) => x + t.hours, 0);
  return `<div class="crumbs"><a href="#/program/${id}">${esc(base.title)}</a> / Versiyalarni solishtirish</div>
  <div class="page-head"><h1>Versiyalarni solishtirish</h1><form class="row right" id="cmpf">${sel('a', a)} <span class="muted">→</span> ${sel('b', b)} <button class="btn primary sm">Solishtirish</button></form></div>
  <div class="alert info small">Eski versiya: <b>v${a}</b> (${esc(A.versions.find(v => v.version_no === a).author)}, ${fmtDT(A.versions.find(v => v.version_no === a).created_at)}) → yangi versiya: <b>v${b}</b>. <del>O'chirilgan</del> va <ins>qo'shilgan</ins> matn ajratib ko'rsatilgan.</div>
  <div class="sec-block"><div class="hd"><h3>Asosiy parametrlar</h3></div><div class="grid g3">${prm}</div></div>
  ${txt('goals', 'Maqsad')}${txt('objectives', 'Vazifalar')}${txt('outcomes', "O'quv natijalari")}
  <div class="sec-block"><div class="hd"><h3>Mavzular</h3><span class="muted small">Soat: ${sa} → ${sb}</span></div><div class="tbl-wrap" style="box-shadow:none"><table class="tbl"><thead><tr><th>Mavzu</th><th style="width:90px">Eski soat</th><th style="width:90px">Yangi soat</th><th style="width:110px">Holat</th></tr></thead><tbody>${trows.map(([t, o, n, k]) => `<tr><td>${k === 'del' ? `<del>${esc(t)}</del>` : k === 'ins' ? `<ins>${esc(t)}</ins>` : esc(t)}</td><td>${o}</td><td>${n}</td><td>${{ ins: '<ins>qo\'shilgan</ins>', del: "<del>o'chirilgan</del>", chg: '<span class="badge revision">soat o\'zgargan</span>', '': '<span class="muted">—</span>' }[k]}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">Mavzu yo\'q</td></tr>'}</tbody></table></div></div>
  ${txt('literature', 'Adabiyotlar')}`;
}, { after: (m) => { $('#cmpf').onsubmit = (e) => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); location.hash = `#/compare/${m[1]}?a=${f.a}&b=${f.b}`; }; } });
document.addEventListener('submit', (e) => { if (e.target.id === 'ef') e.preventDefault(); });
