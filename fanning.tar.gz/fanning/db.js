// Ma'lumotlar bazasi (SQLite, node:sqlite) — sxema va yordamchi funksiyalar
const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'fanning.db');
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, login TEXT UNIQUE NOT NULL,
  pass_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('teacher','methodist','head','admin')),
  email TEXT, position TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created_at TEXT NOT NULL, last_seen INTEGER NOT NULL, ip TEXT
);
CREATE TABLE IF NOT EXISTS directions(id INTEGER PRIMARY KEY, name TEXT NOT NULL, code TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS academic_years(id INTEGER PRIMARY KEY, name TEXT NOT NULL, start_date TEXT, end_date TEXT);
CREATE TABLE IF NOT EXISTS subjects(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, code TEXT NOT NULL, direction_id INTEGER REFERENCES directions(id)
);
CREATE TABLE IF NOT EXISTS templates(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, required_fields TEXT NOT NULL, valid_until TEXT, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS curriculums(
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, subject_id INTEGER NOT NULL REFERENCES subjects(id),
  direction_id INTEGER REFERENCES directions(id), year_id INTEGER NOT NULL REFERENCES academic_years(id),
  template_id INTEGER REFERENCES templates(id),
  author_id INTEGER NOT NULL REFERENCES users(id), reviewer_id INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'draft', current_version INTEGER NOT NULL DEFAULT 1,
  review_due TEXT, approval_due TEXT, doc_code TEXT, pdf_path TEXT, pdf_hash TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS curriculum_versions(
  id INTEGER PRIMARY KEY, curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
  version_no INTEGER NOT NULL, content TEXT NOT NULL, locked INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER NOT NULL REFERENCES users(id), created_at TEXT NOT NULL, note TEXT,
  UNIQUE(curriculum_id, version_no)
);
CREATE TABLE IF NOT EXISTS topics(
  id INTEGER PRIMARY KEY, version_id INTEGER NOT NULL REFERENCES curriculum_versions(id) ON DELETE CASCADE,
  title TEXT NOT NULL, hours INTEGER NOT NULL, ord INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reviews(
  id INTEGER PRIMARY KEY, curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
  version_id INTEGER NOT NULL, reviewer_id INTEGER NOT NULL, started_at TEXT NOT NULL,
  finished_at TEXT, result TEXT, due TEXT
);
CREATE TABLE IF NOT EXISTS comments(
  id INTEGER PRIMARY KEY, review_id INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  curriculum_id INTEGER NOT NULL, version_id INTEGER NOT NULL, section TEXT NOT NULL, text TEXT NOT NULL,
  author_id INTEGER NOT NULL, created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', closed_at TEXT
);
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY, curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
  name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, path TEXT NOT NULL, sha256 TEXT NOT NULL,
  uploaded_by INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS approvals(
  id INTEGER PRIMARY KEY, curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
  version_id INTEGER NOT NULL, head_id INTEGER NOT NULL, decided_at TEXT NOT NULL,
  decision TEXT NOT NULL CHECK(decision IN ('approved','rejected')), reason TEXT
);
CREATE TABLE IF NOT EXISTS status_history(
  id INTEGER PRIMARY KEY, curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
  from_status TEXT, to_status TEXT NOT NULL, actor_id INTEGER, version_no INTEGER, note TEXT, at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, message TEXT NOT NULL, link TEXT, channel TEXT NOT NULL DEFAULT 'app',
  read INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, user_id INTEGER, user_name TEXT, action TEXT NOT NULL, object TEXT, detail TEXT,
  ip TEXT, at TEXT NOT NULL, prev_hash TEXT NOT NULL, hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS login_attempts(login TEXT, at INTEGER);
CREATE INDEX IF NOT EXISTS idx_cur_status ON curriculums(status);
CREATE INDEX IF NOT EXISTS idx_cur_author ON curriculums(author_id);
CREATE INDEX IF NOT EXISTS idx_ver_cur ON curriculum_versions(curriculum_id);
`);

const now = () => new Date().toISOString();
const q = {
  all: (sql, ...p) => db.prepare(sql).all(...p),
  get: (sql, ...p) => db.prepare(sql).get(...p),
  run: (sql, ...p) => db.prepare(sql).run(...p),
};
function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}

// ---- Parol (scrypt hash) ----
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
}
function verifyPassword(pw, stored) {
  const [salt, h] = stored.split(':');
  const a = Buffer.from(h, 'hex'), b = crypto.scryptSync(pw, salt, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ---- Sozlamalar ----
const DEFAULT_SETTINGS = { review_days: '5', approval_days: '5', session_minutes: '30', institution: "Toshkent axborot texnologiyalari ta'lim muassasasi", max_file_mb: '10' };
function getSetting(k) { const r = q.get('SELECT value FROM settings WHERE key=?', k); return r ? r.value : DEFAULT_SETTINGS[k]; }
function allSettings() { const o = { ...DEFAULT_SETTINGS }; for (const r of q.all('SELECT * FROM settings')) o[r.key] = r.value; return o; }

// ---- Audit jurnali: zanjir (hash) bilan — o'zgartirib bo'lmaydi ----
function audit(user, action, object, detail, ip) {
  const last = q.get('SELECT hash FROM audit_log ORDER BY id DESC LIMIT 1');
  const prev = last ? last.hash : 'GENESIS';
  const at = now();
  const body = JSON.stringify([user ? user.id : null, action, object || '', detail || '', at, prev]);
  const hash = crypto.createHash('sha256').update(body).digest('hex');
  q.run('INSERT INTO audit_log(user_id,user_name,action,object,detail,ip,at,prev_hash,hash) VALUES(?,?,?,?,?,?,?,?,?)',
    user ? user.id : null, user ? user.full_name : 'Tizim', action, object || '', detail || '', ip || '', at, prev, hash);
}
function verifyAuditChain() {
  let prev = 'GENESIS';
  for (const r of q.all('SELECT * FROM audit_log ORDER BY id')) {
    const body = JSON.stringify([r.user_id, r.action, r.object || '', r.detail || '', r.at, prev]);
    const h = crypto.createHash('sha256').update(body).digest('hex');
    if (r.prev_hash !== prev || r.hash !== h) return { ok: false, brokenAt: r.id };
    prev = r.hash;
  }
  return { ok: true };
}

function notify(userId, message, link) {
  if (!userId) return;
  q.run('INSERT INTO notifications(user_id,message,link,created_at) VALUES(?,?,?,?)', userId, message, link || null, now());
}

module.exports = { db, q, tx, now, hashPassword, verifyPassword, getSetting, allSettings, audit, verifyAuditChain, notify };
