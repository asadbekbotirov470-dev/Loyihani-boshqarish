// Yadro: yordamchilar, API, router, umumiy maket, kirish sahifasi
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const state = { user: null, meta: null, unread: 0, pages: {}, dirty: false };
const ACT = {}; // data-act uchun ishlovchilar

const ICON = {
  home: '<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>', doc: '<path d="M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v6H3zM3 13h5l1 3h6l1-3h5"/>', check: '<path d="M5 12l5 5 9-10"/>', archive: '<path d="M3 5h18v4H3zM5 9v11h14V9M10 13h4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>', gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-4 3-6 7-6s7 2 7 6M17 4.5a3.5 3.5 0 010 7M22 20c0-3-1.5-5-4-5.8"/>',
  bell: '<path d="M6 17V11a6 6 0 1112 0v6l2 2H4zM10 21h4"/>', menu: '<path d="M4 6h16M4 12h16M4 18h16"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>', down: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>', logout: '<path d="M10 4H5v16h5M15 8l4 4-4 4M9 12h10"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13 7l4 4"/>', send: '<path d="M4 12l16-8-6 16-3-7z"/>', trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>', up: '<path d="M6 15l6-6 6 6"/>', dn: '<path d="M6 9l6 6 6-6"/>',
};
const ic = (n) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICON[n] || ''}</svg>`;

// ---------- API ----------
async function api(method, url, body) {
  const opt = { method, headers: {}, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(url, opt);
  let data = null; try { data = await r.json(); } catch {}
  if (r.status === 401 && !url.includes('/api/login')) { state.user = null; location.hash = '#/login'; throw Object.assign(new Error('Sessiya tugadi'), { silent: true }); }
  if (!r.ok) { const e = new Error((data && data.error) || 'Xatolik'); e.problems = data && data.problems; e.status = r.status; throw e; }
  return data;
}
const GET = (u) => api('GET', u), POST = (u, b) => api('POST', u, b || {}), PUT = (u, b) => api('PUT', u, b), DEL = (u) => api('DELETE', u);
const qs = (o) => Object.entries(o).filter(([, v]) => v !== '' && v != null).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

// ---------- Interfeys yordamchilari ----------
function toast(msg, kind = '') {
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg; $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), kind === 'err' ? 6000 : 3500);
}
const fail = (e) => { if (!e.silent) toast(e.message, 'err'); };
const fmtDate = (iso) => { if (!iso) return '—'; const d = new Date(iso); return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`; };
const fmtDT = (iso) => { if (!iso) return '—'; const d = new Date(iso); return `${fmtDate(iso)} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const fmtSize = (n) => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
const badge = (st, label) => `<span class="badge ${st}">${esc(label || state.meta.status[st])}</span>`;
const initials = (n) => n.split(/\s+/).filter(w => /^\p{L}/u.test(w)).slice(0, 2).map(w => w[0]).join('').toUpperCase();
function daysLeft(iso) {
  if (!iso) return '';
  const d = Math.ceil((new Date(iso) - Date.now()) / 86400000);
  return d < 0 ? `${-d} kun kechikdi` : d === 0 ? 'bugun' : `${d} kun qoldi`;
}

function modal({ title, body, ok = 'Saqlash', okClass = 'primary', cancel = 'Bekor qilish', onOk, wide }) {
  return new Promise((resolve) => {
    const root = $('#modal-root');
    root.innerHTML = `<div class="modal-bg"><form class="modal" ${wide ? 'style="width:min(760px,100%)"' : ''}><div class="mh"><h2>${esc(title)}</h2><button type="button" class="btn ghost sm right" data-close>✕</button></div><div class="mb">${body}</div><div class="mf"><button type="button" class="btn" data-close>${cancel}</button>${ok ? `<button class="btn ${okClass}" type="submit">${ok}</button>` : ''}</div></form></div>`;
    const close = (v) => { root.innerHTML = ''; resolve(v); };
    root.querySelectorAll('[data-close]').forEach(b => b.onclick = () => close(null));
    root.querySelector('.modal-bg').addEventListener('mousedown', e => { if (e.target.classList.contains('modal-bg')) close(null); });
    const f = root.querySelector('form'); const first = f.querySelector('input,select,textarea'); if (first) first.focus();
    f.onsubmit = async (e) => {
      e.preventDefault(); const btn = f.querySelector('button[type=submit]'); if (btn) btn.disabled = true;
      try { const fd = Object.fromEntries(new FormData(f)); const r = onOk ? await onOk(fd, f) : fd; close(r === undefined ? true : r); }
      catch (err) { fail(err); if (btn) btn.disabled = false; if (err.problems) { const m = f.querySelector('.mb'); m.insertAdjacentHTML('afterbegin', `<div class="alert bad"><b>${esc(err.message)}:</b><ul>${err.problems.map(p => `<li>${esc(p)}</li>`).join('')}</ul></div>`); } }
    };
  });
}
const confirmBox = (title, text, ok = 'Ha', cls = 'primary') => modal({ title, body: `<p style="margin:0">${text}</p>`, ok, okClass: cls, cancel: 'Yo\'q' });

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (el && ACT[el.dataset.act]) { e.preventDefault(); Promise.resolve(ACT[el.dataset.act](el, e)).catch(fail); }
  const row = e.target.closest('tr[data-href]');
  if (row && !e.target.closest('a,button')) location.hash = row.dataset.href;
  if (!e.target.closest('.pophover') && !e.target.closest('[data-act="notifs"]')) $$('.pophover').forEach(p => p.remove());
});

// ---------- Router ----------
const routes = [];
const route = (re, fn, opt = {}) => routes.push({ re, fn, ...opt });
async function render() {
  const hash = location.hash.replace(/^#/, '') || '/';
  if (!state.user) { try { state.user = await GET('/api/me'); state.meta = await GET('/api/meta'); } catch { state.user = null; } }
  if (!state.user) { if (hash !== '/login') { location.hash = '#/login'; return; } return renderLogin(); }
  if (hash === '/login') { location.hash = '#/'; return; }
  const [path, query] = hash.split('?'); const params = Object.fromEntries(new URLSearchParams(query || ''));
  for (const r of routes) {
    const m = path.match(r.re);
    if (!m) continue;
    if (r.roles && !r.roles.includes(state.user.role)) return shell('<div class="empty"><h2>Ruxsat yo\'q</h2><p>Bu sahifa sizning rolingiz uchun mavjud emas.</p></div>', path);
    shell('<div class="empty">Yuklanmoqda…</div>', path);
    try { const html = await r.fn(m, params); if (typeof html === 'string') { $('#view').innerHTML = html; } if (r.after) r.after(m, params); }
    catch (e) { if (!e.silent) $('#view').innerHTML = `<div class="alert bad">${esc(e.message)}</div><a href="#/">← Bosh sahifa</a>`; }
    window.scrollTo(0, 0); return;
  }
  shell('<div class="empty"><h2>Sahifa topilmadi</h2><a href="#/">Bosh sahifaga qaytish</a></div>', path);
}
window.addEventListener('hashchange', () => {
  if (state.dirty && !confirm("Saqlanmagan o'zgarishlar bor. Sahifadan chiqasizmi?")) { history.back(); return; }
  state.dirty = false; render();
});
window.addEventListener('beforeunload', (e) => { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

// ---------- Maket ----------
function navItems(role) {
  const A = [['/', 'Bosh sahifa', 'home']];
  if (role === 'teacher') A.push(['/programs', 'Mening dasturlarim', 'doc'], ['/new', 'Yangi dastur', 'plus']);
  if (role === 'methodist') A.push(['/programs', 'Tekshiruv uchun', 'inbox']);
  if (role === 'head') A.push(['/programs', 'Tasdiqlash uchun', 'check']);
  if (role === 'admin') A.push(['/programs', 'Barcha dasturlar', 'doc']);
  A.push(['/archive', 'Elektron arxiv', 'archive'], ['/reports', 'Hisobotlar', 'chart']);
  if (role === 'admin') A.push(['sec', 'Boshqaruv'], ['/admin/users', 'Foydalanuvchilar', 'users'], ['/admin/refs', "Ma'lumotnomalar", 'doc'], ['/admin/settings', 'Sozlamalar', 'gear'], ['/admin/audit', 'Amallar jurnali', 'shield']);
  return A;
}
function shell(inner, path) {
  const u = state.user;
  if (!$('#view')) {
    $('#app').innerHTML = `<div class="shell"><aside class="side" id="side"></aside><div class="main"><header class="top"><button class="icon-btn menu-btn" data-act="menu" aria-label="Menyu">${ic('menu')}</button><div class="muted small" id="roleline"></div><div class="right row" style="gap:12px;position:relative"><button class="icon-btn" data-act="notifs" aria-label="Bildirishnomalar">${ic('bell')}<span class="dot hidden" id="ndot"></span></button><div class="userchip" data-act="profile"><div class="avatar">${esc(initials(u.full_name))}</div><div class="hide-sm"><div style="font-weight:600;line-height:1.1">${esc(u.full_name)}</div><div class="muted small">${esc(state.meta.roles[u.role])}</div></div></div><button class="btn sm" data-act="logout">${ic('logout')} Chiqish</button></div></header><main class="content" id="view"></main></div></div>`;
    pollNotifs();
  }
  const items = navItems(u.role);
  $('#side').innerHTML = `<a class="brand" href="#/" style="color:inherit;text-decoration:none"><span class="logo"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l5 5 9-11"/></svg></span><span>O'quv dasturi<small>Tasdiqlash platformasi</small></span></a><nav class="nav">${items.map(([h, l, i]) => h === 'sec' ? `<div class="sec">${l}</div>` : `<a href="#${h}" class="${(h === '/' ? path === '/' : path === h || path.startsWith(h + '/') || (h === '/programs' && path.startsWith('/program/'))) ? 'active' : ''}">${ic(i)}${l}</a>`).join('')}</nav><div style="margin-top:auto" class="muted small">${esc(state.meta.settings.institution)}</div>`;
  $('#side').classList.remove('open');
  $('#view').innerHTML = inner;
}
ACT.menu = () => $('#side').classList.toggle('open');
ACT.profile = () => { location.hash = '#/profile'; };
ACT.logout = async () => { try { await POST('/api/logout'); } catch {} state.user = null; state.meta = null; $('#app').innerHTML = ''; location.hash = '#/login'; render(); };

async function pollNotifs() {
  if (!state.user) return;
  try {
    const n = await GET('/api/notifications'); state.unread = n.unread; state.notifs = n.items;
    const d = $('#ndot'); if (d) { d.textContent = n.unread; d.classList.toggle('hidden', !n.unread); }
  } catch {}
  clearTimeout(pollNotifs.t); pollNotifs.t = setTimeout(pollNotifs, 30000);
}
ACT.notifs = async (el) => {
  const ex = $('.pophover'); if (ex) { ex.remove(); return; }
  await pollNotifs();
  const items = state.notifs || [];
  const html = `<div class="pophover">${items.length ? items.map(n => `<a class="it ${n.read ? '' : 'unread'}" href="${esc(n.link || '#/')}"><div>${esc(n.message)}</div><div class="muted small">${fmtDT(n.created_at)}</div></a>`).join('') : '<div class="empty">Bildirishnoma yo\'q</div>'}</div>`;
  el.parentElement.insertAdjacentHTML('beforeend', html);
  if (state.unread) { await POST('/api/notifications/read'); const d = $('#ndot'); if (d) d.classList.add('hidden'); }
};

// ---------- Kirish ----------
function renderLogin() {
  $('#app').innerHTML = `<div class="login"><div class="hero"><div class="brand" style="color:#fff"><span class="logo" style="background:rgba(255,255,255,.18)"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l5 5 9-11"/></svg></span><span>Fan o'quv dasturi<small style="color:#b9cfee">Tasdiqlash platformasi</small></span></div>
  <div><h1>O'quv dasturini tayyorlashdan tasdiqlashgacha — yagona elektron muhitda</h1><p>Har bir dastur yagona elektron yozuv: versiyalar, izohlar, muddatlar va yakuniy tasdiq — barchasi shaffof va nazorat ostida.</p>
  <ul><li>Rollar bo'yicha aniq ish jarayoni: o'qituvchi → metodist → rahbar</li><li>Versiyalarni saqlash va solishtirish</li><li>Tasdiqlangan hujjat PDF va QR-kod bilan arxivga joylanadi</li></ul></div><div class="small" style="color:#a9c2e6">2026 · Ta'lim jarayonlarini raqamlashtirish loyihasi</div></div>
  <div class="formside"><form id="lf"><h1 style="margin-bottom:6px">Tizimga kirish</h1><p class="muted" style="margin:0 0 22px">Login va parolingizni kiriting</p><div id="lerr"></div>
  <div class="field"><label class="f" for="lg">Login</label><input id="lg" name="login" type="text" autocomplete="username" required autofocus></div>
  <div class="field"><label class="f" for="pw">Parol</label><input id="pw" name="password" type="password" autocomplete="current-password" required></div>
  <button class="btn primary" style="width:100%;justify-content:center;padding:11px">Kirish</button>
  <div class="demo"><b>Demo hisoblar</b> <span class="muted">(parol: <code>Demo#2026</code>)</span><br>${[['aziz', "O'qituvchi"], ['malika', 'Metodist'], ['akmal', 'Rahbar'], ['admin', 'Administrator']].map(([l, r]) => `<button type="button" data-demo="${l}">${r}</button>`).join('')}</div></form></div></div>`;
  $$('[data-demo]').forEach(b => b.onclick = () => { $('#lg').value = b.dataset.demo; $('#pw').value = 'Demo#2026'; });
  $('#lf').onsubmit = async (e) => {
    e.preventDefault(); const f = e.target; const btn = f.querySelector('.btn.primary'); btn.disabled = true;
    try { state.user = await POST('/api/login', { login: f.login.value.trim(), password: f.password.value }); state.meta = await GET('/api/meta'); $('#app').innerHTML = ''; location.hash = '#/'; render(); }
    catch (err) { $('#lerr').innerHTML = `<div class="alert bad">${esc(err.message)}</div>`; btn.disabled = false; }
  };
}
