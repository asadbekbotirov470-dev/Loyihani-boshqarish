// Arxiv, hisobotlar, administrator paneli, profil
'use strict';

// ---------- Arxiv ----------
function archiveRows(rows) {
  if (!rows.length) return `<tr><td colspan="6"><div class="empty">Arxivda hujjat topilmadi</div></td></tr>`;
  return rows.map(r => `<tr><td><b>${esc(r.doc_code)}</b></td><td><a href="#/program/${r.id}"><b>${esc(r.subject)}</b></a><div class="muted small">${esc(r.subject_code)} · ${esc(r.direction || '')}</div></td><td>${esc(r.year)}</td><td>${esc(r.author)}</td><td class="muted">${fmtDate(r.updated_at)}</td><td class="nowrap"><a class="btn sm" target="_blank" href="/api/programs/${r.id}/pdf?inline=1">Ko'rish</a> <a class="btn sm primary" href="/api/programs/${r.id}/pdf">${ic('down')} PDF</a></td></tr>`).join('');
}
route(/^\/archive$/, async (m, p) => {
  const rows = await GET('/api/archive?' + qs(p));
  return `<div class="page-head"><div><h1>Elektron arxiv</h1><p>Tasdiqlangan o'quv dasturlari. Hujjatlarni faqat o'qish mumkin; har bir ko'rish va yuklab olish jurnalga yoziladi.</p></div></div>
  <form class="filters" id="flt"><input type="text" name="q" placeholder="Fan, kod, hujjat raqami, muallif…" value="${esc(p.q || '')}"><select name="year">${yearOptions(p.year)}</select><select name="subject">${subjectOptions(p.subject)}</select><select name="direction"><option value="">Barcha yo'nalishlar</option>${state.meta.directions.map(x => `<option value="${x.id}" ${String(p.direction) === String(x.id) ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></form>
  <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Hujjat raqami</th><th>Fan</th><th>O'quv yili</th><th>Muallif</th><th>Arxivlangan</th><th></th></tr></thead><tbody>${archiveRows(rows)}</tbody></table></div>`;
}, { after: (m, p) => {
  const f = $('#flt'); let t; const go = () => { location.hash = '#/archive?' + qs(Object.fromEntries(new FormData(f))); };
  f.querySelectorAll('select').forEach(s => s.onchange = go); f.q.oninput = () => { clearTimeout(t); t = setTimeout(go, 400); };
  if (p.q) { f.q.focus(); f.q.setSelectionRange(99, 99); }
} });

// ---------- Hisobotlar ----------
const bars = (arr, max) => { const m = max || Math.max(1, ...arr.map(x => x.n)); return `<div class="bars">${arr.length ? arr.map(x => `<div class="b"><span class="lbl" title="${esc(x.name)}">${esc(x.name)}</span><span class="track"><span class="fill" style="width:${(x.n / m) * 100}%"></span></span><b>${x.n}</b></div>`).join('') : '<div class="muted small">Ma\'lumot yo\'q</div>'}</div>`; };
route(/^\/reports$/, async (m, p) => {
  const d = await GET('/api/reports?' + qs(p)); const s = d.summary; const M = state.meta;
  const opt = (arr, key, lab, sel, all) => `<select name="${key}"><option value="">${all}</option>${arr.map(x => `<option value="${x.id}" ${String(sel) === String(x.id) ? 'selected' : ''}>${esc(x[lab])}</option>`).join('')}</select>`;
  const q = qs(p);
  return `<div class="page-head"><div><h1>Hisobotlar va monitoring</h1><p>Filtrlang va Excel yoki PDF ko'rinishida yuklab oling</p></div><div class="right row"><a class="btn" href="/api/reports/export.xlsx?${q}">${ic('down')} Excel</a><a class="btn" href="/api/reports/export.pdf?${q}">${ic('down')} PDF</a></div></div>
  <form class="filters" id="flt">${opt(M.years, 'year', 'name', p.year, "Barcha o'quv yillari")}${opt(M.subjects, 'subject', 'name', p.subject, 'Barcha fanlar')}${opt(M.directions, 'direction', 'name', p.direction, "Barcha yo'nalishlar")}${state.user.role === 'teacher' ? '' : opt(M.teachers, 'teacher', 'full_name', p.teacher, "Barcha o'qituvchilar")}
  <select name="status"><option value="">Barcha holatlar</option>${Object.entries(M.status).map(([k, v]) => `<option value="${k}" ${p.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select><input type="date" name="from" value="${esc(p.from || '')}" title="Boshlanish sanasi"><input type="date" name="to" value="${esc(p.to || '')}" title="Tugash sanasi"><a class="btn" href="#/reports">Tozalash</a></form>
  <div class="grid g7"><div class="stat"><div class="n">${s.total}</div><div class="l">Jami dasturlar</div></div><div class="stat good"><div class="n">${s.approved}</div><div class="l">Tasdiqlangan</div></div><div class="stat"><div class="n">${s.in_review}</div><div class="l">Jarayonda</div></div><div class="stat"><div class="n">${s.returned_now}</div><div class="l">Tuzatishda / rad etilgan</div></div><div class="stat ${s.overdue ? 'warn' : ''}"><div class="n">${s.overdue}</div><div class="l">Muddati o'tgan</div></div><div class="stat"><div class="n">${s.avg_total_days ?? '—'}</div><div class="l">O'rtacha tasdiqlash (kun)</div></div><div class="stat"><div class="n">${s.avg_returns}</div><div class="l">Qaytarishlar / dastur</div></div></div>
  <div class="grid g2" style="margin-top:20px"><div class="card"><h2>Holatlar bo'yicha</h2>${bars(d.byStatus.filter(x => x.n).map(x => ({ name: x.name, n: x.n })))}</div><div class="card"><h2>Bosqichlar o'rtacha davomiyligi (kun)</h2><div class="tbl-wrap" style="box-shadow:none;border:none"><table class="tbl"><tbody>${d.stageAvg.map(x => `<tr><td>${esc(x.name)}</td><td style="width:90px"><b>${x.days}</b></td><td class="muted small" style="width:70px">${x.n} ta</td></tr>`).join('') || '<tr><td class="muted">Ma\'lumot yo\'q</td></tr>'}</tbody></table></div></div>
  <div class="card"><h2>Fanlar kesimida</h2>${bars(d.bySubject)}</div><div class="card"><h2>O'qituvchilar bo'yicha</h2>${bars(d.byTeacher)}</div><div class="card"><h2>O'quv yillari bo'yicha</h2>${bars(d.byYear)}</div><div class="card"><h2>Yo'nalishlar bo'yicha</h2>${bars(d.byDirection)}</div></div>
  <h2 style="margin:24px 0 12px">Dasturlar ro'yxati (${d.rows.length})</h2><div class="tbl-wrap"><table class="tbl"><thead><tr><th>№</th><th>Fan</th><th>O'quv yili</th><th>Muallif</th><th>Holat</th><th>Yangilangan</th></tr></thead><tbody>${programRows(d.rows)}</tbody></table></div>`;
}, { roles: ['teacher', 'methodist', 'head', 'admin'], after: () => { const f = $('#flt'); f.querySelectorAll('select,input').forEach(i => i.onchange = () => { location.hash = '#/reports?' + qs(Object.fromEntries(new FormData(f))); }); } });

// ---------- Profil ----------
route(/^\/profile$/, async () => {
  const u = state.user;
  return `<div class="page-head"><h1>Profil</h1></div><div class="grid g2"><div class="card"><h2>Shaxsiy ma'lumotlar</h2><form id="pf"><div class="field"><label class="f">F.I.Sh.</label><input type="text" name="full_name" value="${esc(u.full_name)}" required></div><div class="field"><label class="f">Login</label><input type="text" value="${esc(u.login)}" disabled></div><div class="field"><label class="f">Rol</label><input type="text" value="${esc(state.meta.roles[u.role])}" disabled></div><div class="field"><label class="f">Lavozim</label><input type="text" name="position" value="${esc(u.position || '')}"></div><div class="field"><label class="f">Elektron pochta</label><input type="email" name="email" value="${esc(u.email || '')}"></div><button class="btn primary">Saqlash</button></form></div>
  <div class="card"><h2>Parolni o'zgartirish</h2><form id="pw"><div class="field"><label class="f">Joriy parol</label><input type="password" name="old_password" required autocomplete="current-password"></div><div class="field"><label class="f">Yangi parol</label><input type="password" name="new_password" minlength="8" required autocomplete="new-password"><div class="hint">Kamida 8 belgi</div></div><button class="btn primary">Parolni yangilash</button></form></div></div>`;
}, { after: () => {
  $('#pf').onsubmit = async (e) => { e.preventDefault(); try { await PUT('/api/me', Object.fromEntries(new FormData(e.target))); state.user = await GET('/api/me'); toast('Saqlandi', 'ok'); } catch (x) { fail(x); } };
  $('#pw').onsubmit = async (e) => { e.preventDefault(); try { await POST('/api/me/password', Object.fromEntries(new FormData(e.target))); e.target.reset(); toast('Parol yangilandi', 'ok'); } catch (x) { fail(x); } };
} });

// ---------- Administrator ----------
const adminTabs = (a) => `<div class="tabs">${[['users', 'Foydalanuvchilar'], ['refs', "Ma'lumotnomalar"], ['settings', 'Sozlamalar'], ['audit', 'Amallar jurnali']].map(([k, l]) => `<button data-act="goto" data-to="#/admin/${k}" class="${k === a ? 'active' : ''}">${l}</button>`).join('')}</div>`;
ACT.goto = (el) => { location.hash = el.dataset.to; };

route(/^\/admin\/users$/, async () => {
  const us = await GET('/api/admin/users'); window._users = us;
  return `<div class="page-head"><div><h1>Foydalanuvchilar</h1><p>Hisoblar va rollarni boshqarish</p></div><button class="btn primary right" data-act="user-new">${ic('plus')} Yangi foydalanuvchi</button></div>${adminTabs('users')}
  <div class="tbl-wrap"><table class="tbl"><thead><tr><th>F.I.Sh.</th><th>Login</th><th>Rol</th><th>Lavozim</th><th>Holat</th><th></th></tr></thead><tbody>${us.map(u => `<tr><td><b>${esc(u.full_name)}</b><div class="muted small">${esc(u.email || '')}</div></td><td>${esc(u.login)}</td><td>${esc(state.meta.roles[u.role])}</td><td class="muted">${esc(u.position || '')}</td><td>${u.active ? badge('approved', 'Faol') : badge('rejected', 'Bloklangan')}</td><td><button class="btn sm" data-act="user-edit" data-id="${u.id}">Tahrirlash</button></td></tr>`).join('')}</tbody></table></div>`;
}, { roles: ['admin'] });
const userForm = (u = {}) => `<div class="field"><label class="f">F.I.Sh.</label><input type="text" name="full_name" value="${esc(u.full_name || '')}" required></div>
  ${u.id ? '' : `<div class="field"><label class="f">Login</label><input type="text" name="login" required></div>`}
  <div class="grid g2"><div class="field"><label class="f">Rol</label><select name="role">${Object.entries(state.meta.roles).map(([k, v]) => `<option value="${k}" ${u.role === k ? 'selected' : ''}>${v}</option>`).join('')}</select></div><div class="field"><label class="f">Lavozim</label><input type="text" name="position" value="${esc(u.position || '')}"></div></div>
  <div class="field"><label class="f">Elektron pochta</label><input type="email" name="email" value="${esc(u.email || '')}"></div>
  <div class="field"><label class="f">${u.id ? 'Yangi parol (o\'zgartirmaslik uchun bo\'sh qoldiring)' : 'Parol'}</label><input type="password" name="password" minlength="8" ${u.id ? '' : 'required'} autocomplete="new-password"></div>
  ${u.id ? `<div class="field"><label class="f">Holat</label><select name="active"><option value="1" ${u.active ? 'selected' : ''}>Faol</option><option value="0" ${u.active ? '' : 'selected'}>Bloklangan</option></select></div>` : ''}`;
ACT['user-new'] = async () => { if (await modal({ title: 'Yangi foydalanuvchi', body: userForm(), onOk: (f) => POST('/api/admin/users', f) })) { toast('Yaratildi', 'ok'); render(); } };
ACT['user-edit'] = async (el) => {
  const u = window._users.find(x => x.id === +el.dataset.id);
  if (await modal({ title: 'Foydalanuvchini tahrirlash', body: userForm(u), onOk: (f) => { f.active = +f.active; if (!f.password) delete f.password; return PUT(`/api/admin/users/${u.id}`, f); } })) { toast('Saqlandi', 'ok'); render(); }
};

const REFS = {
  directions: { title: "Ta'lim yo'nalishlari", cols: [['name', 'Nomi'], ['code', 'Kodi']] },
  years: { title: "O'quv yillari", cols: [['name', 'Nomi'], ['start_date', 'Boshlanish', 'date'], ['end_date', 'Tugash', 'date']] },
  subjects: { title: 'Fanlar', cols: [['name', 'Fan nomi'], ['code', 'Kodi'], ['direction_id', "Yo'nalish", 'dir']] },
  templates: { title: 'Dastur shablonlari', cols: [['name', 'Nomi'], ['valid_until', 'Amal qilish muddati', 'date'], ['required_fields', 'Majburiy maydonlar', 'fields']] },
};
route(/^\/admin\/refs$/, async () => {
  const [dirs, years, subs, tpls] = await Promise.all([GET('/api/meta'), 0, 0, GET('/api/admin/templates')]); const M = dirs; state.meta = M; window._tpls = tpls;
  const data = { directions: M.directions, years: M.years, subjects: M.subjects, templates: tpls };
  const cell = (r, c) => { const v = r[c[0]]; return c[2] === 'dir' ? esc((M.directions.find(d => d.id === v) || {}).name || '—') : c[2] === 'fields' ? v.map(f => esc(M.fields[f])).join(', ') : c[2] === 'date' ? fmtDate(v) : esc(v); };
  return `<div class="page-head"><div><h1>Ma'lumotnomalar</h1><p>Yo'nalishlar, o'quv yillari, fanlar va dastur shablonlari</p></div></div>${adminTabs('refs')}
  ${Object.entries(REFS).map(([k, R]) => `<div class="card"><h2>${R.title}<button class="btn sm right" data-act="ref-new" data-k="${k}">${ic('plus')} Qo'shish</button></h2><div class="tbl-wrap" style="box-shadow:none"><table class="tbl"><thead><tr>${R.cols.map(c => `<th>${c[1]}</th>`).join('')}<th></th></tr></thead><tbody>${data[k].map(r => `<tr>${R.cols.map(c => `<td>${cell(r, c)}</td>`).join('')}<td class="nowrap"><button class="btn sm" data-act="ref-edit" data-k="${k}" data-id="${r.id}">Tahrirlash</button> <button class="btn sm ghost" data-act="ref-del" data-k="${k}" data-id="${r.id}">${ic('trash')}</button></td></tr>`).join('') || `<tr><td colspan="9" class="muted">Yozuv yo'q</td></tr>`}</tbody></table></div></div>`).join('')}`;
}, { roles: ['admin'] });
function refForm(k, r = {}) {
  return REFS[k].cols.map(c => {
    if (c[2] === 'date') return `<div class="field"><label class="f">${c[1]}</label><input type="date" name="${c[0]}" value="${esc(r[c[0]] || '')}"></div>`;
    if (c[2] === 'dir') return `<div class="field"><label class="f">${c[1]}</label><select name="direction_id"><option value="">—</option>${state.meta.directions.map(d => `<option value="${d.id}" ${r.direction_id === d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></div>`;
    if (c[2] === 'fields') return `<div class="field"><label class="f">${c[1]}</label>${Object.entries(state.meta.fields).map(([f, l]) => `<label style="display:flex;gap:8px;margin:4px 0"><input type="checkbox" name="f_${f}" ${(r.required_fields || Object.keys(state.meta.fields)).includes(f) ? 'checked' : ''}> ${l}</label>`).join('')}</div>`;
    return `<div class="field"><label class="f">${c[1]}</label><input type="text" name="${c[0]}" value="${esc(r[c[0]] || '')}" required></div>`;
  }).join('') + (k === 'templates' ? `<div class="field"><label style="display:flex;gap:8px"><input type="checkbox" name="active" ${r.active === 0 ? '' : 'checked'}> Faol</label></div>` : '');
}
function refPayload(k, f) {
  const o = { ...f };
  if (k === 'templates') { o.required_fields = Object.keys(state.meta.fields).filter(x => f['f_' + x]); o.active = f.active ? 1 : 0; Object.keys(f).filter(x => x.startsWith('f_')).forEach(x => delete o[x]); }
  if (k === 'subjects') o.direction_id = o.direction_id ? +o.direction_id : null;
  return o;
}
const refRows = (k) => ({ directions: state.meta.directions, years: state.meta.years, subjects: state.meta.subjects, templates: window._tpls })[k];
ACT['ref-new'] = async (el) => { const k = el.dataset.k; if (await modal({ title: REFS[k].title + ": qo'shish", body: refForm(k), onOk: (f) => POST(`/api/admin/${k}`, refPayload(k, f)) })) { await refreshMeta(); } };
ACT['ref-edit'] = async (el) => { const k = el.dataset.k; const r = refRows(k).find(x => x.id === +el.dataset.id); if (await modal({ title: REFS[k].title + ': tahrirlash', body: refForm(k, r), onOk: (f) => PUT(`/api/admin/${k}/${r.id}`, refPayload(k, f)) })) { await refreshMeta(); } };
ACT['ref-del'] = async (el) => { if (await confirmBox("O'chirish", "Yozuv o'chiriladi. Davom etasizmi?", "O'chirish", 'danger')) { await DEL(`/api/admin/${el.dataset.k}/${el.dataset.id}`); await refreshMeta(); } };
async function refreshMeta() { state.meta = await GET('/api/meta'); toast('Saqlandi', 'ok'); render(); }

route(/^\/admin\/settings$/, async () => {
  const s = await GET('/api/admin/settings');
  return `<div class="page-head"><div><h1>Tizim sozlamalari</h1></div></div>${adminTabs('settings')}<div class="card" style="max-width:640px"><form id="sf"><div class="field"><label class="f">Muassasa nomi (PDF sarlavhasida)</label><input type="text" name="institution" value="${esc(s.institution)}"></div>
  <div class="grid g2"><div class="field"><label class="f">Metodik tekshiruv muddati (kun)</label><input type="number" min="1" name="review_days" value="${esc(s.review_days)}"></div><div class="field"><label class="f">Rahbar qarori muddati (kun)</label><input type="number" min="1" name="approval_days" value="${esc(s.approval_days)}"></div>
  <div class="field"><label class="f">Faolsizlikda chiqish (daqiqa)</label><input type="number" min="1" name="session_minutes" value="${esc(s.session_minutes)}"></div><div class="field"><label class="f">Maksimal fayl hajmi (MB)</label><input type="number" min="1" max="15" name="max_file_mb" value="${esc(s.max_file_mb)}"></div></div><button class="btn primary">Saqlash</button></form></div>`;
}, { roles: ['admin'], after: () => { $('#sf').onsubmit = async (e) => { e.preventDefault(); try { await PUT('/api/admin/settings', Object.fromEntries(new FormData(e.target))); state.meta = await GET('/api/meta'); toast('Sozlamalar saqlandi', 'ok'); } catch (x) { fail(x); } }; } });

route(/^\/admin\/audit$/, async (m, p) => {
  const d = await GET('/api/admin/audit?' + qs(p));
  return `<div class="page-head"><div><h1>Amallar jurnali</h1><p>Muhim amallar o'zgartirib bo'lmaydigan zanjir (SHA-256) ko'rinishida yoziladi</p></div><div class="right">${d.chain.ok ? '<span class="badge approved">✓ Jurnal butunligi tasdiqlangan</span>' : `<span class="badge rejected">Jurnal buzilgan! (yozuv №${d.chain.brokenAt})</span>`}</div></div>${adminTabs('audit')}
  <form class="filters" id="flt"><input type="text" name="q" placeholder="Foydalanuvchi, obyekt…" value="${esc(p.q || '')}"><select name="action"><option value="">Barcha amallar</option>${['login', 'logout', 'curriculum', 'status', 'comment', 'file', 'archive', 'user', 'settings', 'report', 'pdf', 'password'].map(a => `<option value="${a}" ${p.action === a ? 'selected' : ''}>${a}</option>`).join('')}</select></form>
  <div class="tbl-wrap"><table class="tbl"><thead><tr><th>№</th><th>Vaqt</th><th>Foydalanuvchi</th><th>Amal</th><th>Obyekt</th><th>Tafsilot</th><th>IP</th></tr></thead><tbody>${d.rows.map(r => `<tr><td class="muted">${r.id}</td><td class="nowrap">${fmtDT(r.at)}</td><td>${esc(r.user_name)}</td><td><code>${esc(r.action)}</code></td><td class="muted">${esc(r.object)}</td><td>${esc(r.detail)}</td><td class="muted small">${esc(r.ip)}</td></tr>`).join('')}</tbody></table></div>`;
}, { roles: ['admin'], after: (m, p) => { const f = $('#flt'); let t; const go = () => { location.hash = '#/admin/audit?' + qs(Object.fromEntries(new FormData(f))); }; f.action.onchange = go; f.q.oninput = () => { clearTimeout(t); t = setTimeout(go, 400); }; if (p.q) { f.q.focus(); f.q.setSelectionRange(99, 99); } } });
