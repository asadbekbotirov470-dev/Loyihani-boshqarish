// Boshlang'ich ma'lumotlar: foydalanuvchilar, ma'lumotnomalar va namunaviy dasturlar
const { q, tx, hashPassword, now } = require('./db');
const W = require('./lib/workflow');

const DEMO_PASSWORD = process.env.DEMO_PASSWORD || 'Demo#2026';

const content = (course, semester, total, goals, objectives, outcomes, literature, topics) =>
  ({ course, semester, total_hours: total, goals, objectives, outcomes, literature, topics: topics.map(([title, hours]) => ({ title, hours })) });

const SAMPLES = {
  prog: content('1', '1', 120,
    "Talabalarda dasturlash tafakkurini shakllantirish, algoritmik masalalarni yechish va zamonaviy dasturlash tilida amaliy ko'nikmalarni rivojlantirish.",
    "- Dasturlash tilining asosiy konstruksiyalarini o'rgatish\n- Algoritm va blok-sxemalar bilan ishlash ko'nikmasini berish\n- Funksiya, massiv va fayllar bilan ishlashni o'rgatish\n- Kichik loyihalarni mustaqil bajarish malakasini shakllantirish",
    "Talaba: o'zgaruvchi, shart va sikl operatorlaridan foydalana oladi; funksiyalar yozadi; oddiy ma'lumotlar tuzilmalarini qo'llaydi; 300 qatorgacha dasturni mustaqil ishlab chiqadi.",
    "1. Kernighan B., Ritchie D. The C Programming Language. — Prentice Hall, 2020.\n2. Axmedov A. Dasturlash asoslari. — Toshkent: Fan, 2023.\n3. https://cppreference.com",
    [['Dasturlash tillariga kirish va muhitni sozlash', 10], ["O'zgaruvchilar va ma'lumot turlari", 14], ['Shart operatorlari', 14], ['Sikl operatorlari', 16], ['Funksiyalar', 18], ['Massivlar va satrlar', 18], ['Fayllar bilan ishlash', 14], ['Yakuniy mini-loyiha', 16]]),
  db: content('2', '3', 90,
    "Relyatsion ma'lumotlar bazalarini loyihalash, SQL tili va ma'lumotlarni boshqarish tamoyillarini o'rgatish.",
    "- ER-modellashtirish va normallashtirishni o'rgatish\n- SQL so'rovlarini yozish ko'nikmasini shakllantirish\n- Tranzaksiya va indekslar bilan tanishtirish",
    "Talaba ER-diagramma tuza oladi, 3NF gacha normallashtiradi, murakkab SQL so'rovlarini yozadi.",
    "1. Date C.J. An Introduction to Database Systems. — Pearson, 2019.\n2. PostgreSQL rasmiy hujjatlari: https://postgresql.org/docs",
    [["Ma'lumotlar bazasiga kirish", 10], ['ER-model', 16], ['Normallashtirish', 16], ['SQL: SELECT va JOIN', 20], ['SQL: agregatsiya va ichki so\'rovlar', 16], ['Tranzaksiya va indekslar', 12]]),
  ds: content('2', '4', 80,
    "Asosiy algoritmlar va ma'lumotlar tuzilmalarini o'rgatish, ularning murakkabligini baholash ko'nikmasini shakllantirish.",
    "- Massiv, ro'yxat, stek, navbat, daraxt va graflarni o'rgatish\n- Saralash va qidiruv algoritmlarini tahlil qilish",
    "Talaba algoritm murakkabligini baholaydi va masalaga mos ma'lumotlar tuzilmasini tanlay oladi.",
    "1. Cormen T. Introduction to Algorithms. — MIT Press, 2022.",
    [['Algoritm murakkabligi', 10], ["Ro'yxatlar, stek, navbat", 16], ['Saralash algoritmlari', 18], ['Daraxtlar', 18], ['Graflar', 18]]),
  math: content('1', '2', 100,
    "Oliy matematikaning asosiy bo'limlari bo'yicha nazariy bilim va hisoblash ko'nikmalarini berish.",
    "- Chiziqli algebra va analitik geometriya\n- Differensial va integral hisob",
    "Talaba limit, hosila va integrallarni hisoblaydi, chiziqli tenglamalar sistemasini yechadi.",
    "1. Piskunov N. Differensial va integral hisob. — Toshkent: O'qituvchi, 2021.",
    [['Matritsa va determinantlar', 20], ['Limitlar', 20], ['Hosila', 30], ['Integral', 30]]),
  net: content('3', '5', 72,
    "Kompyuter tarmoqlari arxitekturasi va protokollarini o'rgatish.",
    "- OSI va TCP/IP modellari\n- Marshrutlash va kommutatsiya",
    "Talaba kichik tarmoqni loyihalaydi va sozlaydi.",
    "1. Tanenbaum A. Computer Networks. — Pearson, 2021.",
    [['Tarmoq modellari', 12], ['IP-manzillash', 20], ['Marshrutlash', 20], ['Xavfsizlik asoslari', 20]]),
};

async function seedIfEmpty() {
  if (q.get('SELECT COUNT(*) n FROM users').n > 0) return;
  console.log('Boshlang\'ich ma\'lumotlar yuklanmoqda...');
  const ins = (sql, ...p) => Number(q.run(sql, ...p).lastInsertRowid);
  const mkUser = (name, login, role, pos) => ins('INSERT INTO users(full_name,login,pass_hash,role,email,position,created_at) VALUES(?,?,?,?,?,?,?)',
    name, login, hashPassword(login === 'admin' ? (process.env.ADMIN_PASSWORD || DEMO_PASSWORD) : DEMO_PASSWORD), role, `${login}@example.uz`, pos, now());

  mkUser('Administrator', 'admin', 'admin', 'Tizim administratori');
  const t1 = mkUser('Aziz Karimov', 'aziz', 'teacher', 'Katta o\'qituvchi');
  const t2 = mkUser('Dilnoza Yusupova', 'dilnoza', 'teacher', 'Dotsent');
  const t3 = mkUser('Bobur Rahimov', 'bobur', 'teacher', "O'qituvchi");
  const m1 = mkUser('Malika Nazarova', 'malika', 'methodist', "O'quv-metodik bo'lim metodisti");
  const m2 = mkUser('Sherzod Olimov', 'sherzod', 'methodist', 'Bosh metodist');
  const h1 = mkUser('Prof. Akmal Saidov', 'akmal', 'head', "O'quv ishlari bo'yicha prorektor");

  const dIT = ins('INSERT INTO directions(name,code) VALUES(?,?)', 'Axborot texnologiyalari', '60610100');
  const dMath = ins('INSERT INTO directions(name,code) VALUES(?,?)', 'Amaliy matematika', '60540200');
  const y1 = ins('INSERT INTO academic_years(name,start_date,end_date) VALUES(?,?,?)', '2025-2026', '2025-09-01', '2026-06-30');
  const y2 = ins('INSERT INTO academic_years(name,start_date,end_date) VALUES(?,?,?)', '2026-2027', '2026-09-01', '2027-06-30');
  const S = {};
  [['prog', 'Dasturlash asoslari', 'DA101', dIT], ['db', "Ma'lumotlar bazasi", 'MB204', dIT], ['ds', "Algoritmlar va ma'lumotlar tuzilmasi", 'AM203', dIT],
    ['math', 'Oliy matematika', 'OM101', dMath], ['net', 'Kompyuter tarmoqlari', 'KT301', dIT], ['web', 'Web dasturlash', 'WD305', dIT], ['ai', "Sun'iy intellekt asoslari", 'SI401', dIT],
    ['econ', 'Iqtisodiyot nazariyasi', 'IN102', dMath]].forEach(([k, n, c, d]) => { S[k] = ins('INSERT INTO subjects(name,code,direction_id) VALUES(?,?,?)', n, c, d); });
  ins('INSERT INTO templates(name,required_fields,valid_until,active) VALUES(?,?,?,1)', "Standart fan o'quv dasturi shabloni",
    JSON.stringify(['course', 'semester', 'total_hours', 'goals', 'objectives', 'outcomes', 'literature', 'topics']), '2027-12-31');

  const U = (id) => q.get('SELECT * FROM users WHERE id=?', id);
  const create = (user, subj, year, key, partial) => {
    const id = W.createCurriculum(U(user), { subject_id: S[subj], year_id: year });
    W.saveContent(U(user), id, partial ? { ...SAMPLES[key], topics: SAMPLES[key].topics.slice(0, 3), literature: '' } : SAMPLES[key]);
    return id;
  };
  const go = (user, id, to, p) => W.transition(U(user), id, to, p);
  const back = (id, days) => { // tarixni o'tmishga siljitish (hisobotlar mazmunli ko'rinishi uchun)
    const h = q.all('SELECT id FROM status_history WHERE curriculum_id=? ORDER BY id', id);
    h.forEach((r, i) => q.run('UPDATE status_history SET at=? WHERE id=?', new Date(Date.now() - (days * (h.length - i) / h.length) * 86400000).toISOString(), r.id));
    q.run('UPDATE curriculums SET created_at=? WHERE id=?', new Date(Date.now() - days * 86400000).toISOString(), id);
  };

  // 1. Qoralama
  back(create(t1, 'web', y2, 'prog', true), 1);
  // 2. Yuborilgan — muddati o'tgan
  let id = create(t2, 'db', y2, 'db'); go(t2, id, 'submitted', { reviewer_id: m1 });
  q.run('UPDATE curriculums SET review_due=? WHERE id=?', new Date(Date.now() - 3 * 86400000).toISOString(), id); back(id, 9);
  // 3. Tekshirilmoqda (bitta ochiq, bitta yopiq izoh)
  id = create(t1, 'ds', y2, 'ds'); go(t1, id, 'submitted', { reviewer_id: m1 }); go(m1, id, 'in_review');
  W.addComment(U(m1), id, 'outcomes', "O'quv natijalari o'lchanadigan fe'llar bilan (bilishi, qo'llay olishi) ifodalansin.");
  const c2 = W.addComment(U(m1), id, 'literature', "Adabiyotlar ro'yxatiga o'zbek tilidagi darslik qo'shing."); W.setCommentStatus(U(m1), c2, 'closed'); back(id, 3);
  // 4. Tuzatish talab qilinadi
  id = create(t3, 'net', y2, 'net'); go(t3, id, 'submitted', { reviewer_id: m2 }); go(m2, id, 'in_review');
  W.addComment(U(m2), id, 'topics', 'Xavfsizlik mavzusiga 8 soat ajrating, tarmoq modellari qisqartirilsin.');
  W.addComment(U(m2), id, 'goals', 'Maqsad aniqroq yozilsin.'); go(m2, id, 'revision'); back(id, 5);
  // 5. Tasdiqlashga tayyor
  id = create(t2, 'math', y2, 'math'); go(t2, id, 'submitted', { reviewer_id: m2 }); go(m2, id, 'in_review'); go(m2, id, 'ready'); back(id, 6);
  // 6. Rad etildi (v1 rad etilgan)
  id = create(t1, 'ai', y2, 'ds'); go(t1, id, 'submitted', { reviewer_id: m1 }); go(m1, id, 'in_review'); go(m1, id, 'ready');
  go(h1, id, 'rejected', { reason: "Dastur mazmuni fan nomiga mos emas: sun'iy intellekt mavzulari yo'q. Qayta ishlab chiqing." }); back(id, 7);

  // 7-8. Arxivlangan (PDF bilan) — 2025-2026 o'quv yili
  for (const [t, m, subj, yr, key, days] of [[t1, m1, 'prog', y1, 'prog', 40], [t2, m2, 'econ', y1, 'math', 25]]) {
    id = create(t, subj, yr, key); go(t, id, 'submitted', { reviewer_id: m });
    go(m, id, 'in_review'); const cm = W.addComment(U(m), id, 'general', 'Rasmiylashtirish bo\'yicha kichik izoh.');
    go(m, id, 'revision'); W.saveContent(U(t), id, SAMPLES[key]); go(t, id, 'resubmitted'); go(m, id, 'in_review');
    W.setCommentStatus(U(m), cm, 'closed'); go(m, id, 'ready'); go(h1, id, 'approved');
    await W.finalizeApproval(id); back(id, days);
  }
  q.run("INSERT INTO notifications(user_id,message,link,created_at) VALUES(?,?,?,?)", t3, "Xush kelibsiz! «Kompyuter tarmoqlari» dasturi tuzatish uchun qaytarilgan.", '#/program/4', now());
  console.log(`Tayyor. Demo parol: ${DEMO_PASSWORD}`);
}

module.exports = { seedIfEmpty, DEMO_PASSWORD };
