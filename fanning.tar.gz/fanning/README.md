# Fanning o'quv dasturini tasdiqlash platformasi

Ishga tushirish (Node.js 22+):

    npm install
    npm start          # http://localhost:3000

Birinchi ishga tushishda demo ma'lumotlar yuklanadi. Demo parol: `Demo#2026`
Loginlar: `aziz`, `dilnoza`, `bobur` (o'qituvchi) · `malika`, `sherzod` (metodist) · `akmal` (rahbar) · `admin`.

Muhit o'zgaruvchilari: `PORT`, `PUBLIC_URL` (QR-kod havolasi), `COOKIE_SECURE=1` (HTTPS ortida), `ADMIN_PASSWORD`, `DEMO_PASSWORD` (birinchi yuklashdan oldin).
Ishlab chiqarishda demo foydalanuvchilarni o'chiring/parolni almashtiring va HTTPS ortida ishlating.

Tuzilma: `db.js` (sxema, audit zanjiri) · `lib/workflow.js` (holatlar, o'tish jadvali, versiyalash) · `lib/pdf.js` · `server.js` (REST API) · `public/` (interfeys).
